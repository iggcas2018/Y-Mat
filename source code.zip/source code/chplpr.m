function Dmun=chplpr(E,v) 
            global Modeca
            if Modeca==1 %%%ƽ��Ӧ��
                Dmun=[1 v 0;v 1 0;0 0 (1-v)];
                Dmun=Dmun*E/(1-v^2);
            else        %%%ƽ��Ӧ��
                Dmun=[1-v v 0;v 1-v 0;0 0 (1-2*v)];
                Dmun=Dmun*E/(1+v)*(1-2*v);
            end
end