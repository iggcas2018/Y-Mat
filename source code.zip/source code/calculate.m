function ForceContact=calculate(block_inset,platen_inset,DFN1_inset,deltatime)
           global IE NewPoint Vol  CC ZZ Astore Interprop sldis
           penn_block=block_inset(8); 
           pent_block=block_inset(9);
           fric_block=block_inset(2);
           penn_platen=platen_inset(8);
           pent_platen=platen_inset(9);
           fric_platen=platen_inset(2);
           penn_DFN=DFN1_inset(8);
           pent_DFN=DFN1_inset(9);
           fric_DFN=DFN1_inset(2);
           ForceContact=zeros(3*IE,2);%%%%��Ϊ�������ȫ�������ÿ�μ����꣬Ӧ��0��ʼ���㣬���򽫻����ȫ������
           eleto=zeros(2,3);
           curx=zeros(2,3);
           cury=zeros(2,3);
           norx=zeros(2,3);
           nory=zeros(2,3);
           volx=zeros(2,3);
           voly=zeros(2,3);
           for ii=1:IE
               icoup=CC(ii);
               while icoup>0
                   if Astore(icoup)<0  %26-28 us
                       %tic %6-7us-----------��getoutnormn�ŵ����棬����μ�С��4us
                       %tic
                       ielem=ii;
                       jelem=-1-Astore(icoup);
                       jt=jelem;
                       
                       for jj=1:2
                           for kk=1:3                   %%����Ԫ�Ľ���ת����������Ԫ�Ľ���/��
                               eleto(jj,kk)=3*(jt-1)+kk;%%eleto=[jelem��Ԫ��1���棬2���棬3���棻ielem��Ԫ��1���棬2���棬3����]
                           end                          %%
                           jt=ielem;
                       end
                       %tic
                       for jj=1:2                      %%��ÿ���ڵ��������ٶ�ȡ�����浽������
                           for kk=1:3
                               %a1=eleto(jj,kk);
                               curx(jj,kk)=NewPoint(eleto(jj,kk),1);%%NewPoint()?����Interface?
                               cury(jj,kk)=NewPoint(eleto(jj,kk),2);
                               volx(jj,kk)=Vol(eleto(jj,kk),1);
                               voly(jj,kk)=Vol(eleto(jj,kk),2);
                           end
                       end
                       %toc
                       %tic
                       for jj=1:2   %%%������������ⷨ�ߵ�λ����
                           for kk=1:3
                               hh=kk+1;
                               if hh>3
                                   hh=1;
                               end
                               
                               [nx,ny]= get3outnormn(curx(jj,kk),cury(jj,kk),curx(jj,hh),cury(jj,hh));
                              
                               norx(jj,kk)=nx;
                               nory(jj,kk)=ny;%%%ii??
                           end
                       end   
                       %toc
                       %tic  %20-22us   �������棬����7-8us
                       for jj=1:2              %%curx(2,3)=[x1,x2,x3]
                           mm=jj+1;                       %[x4,x5,x6]
                           if mm>2
                               mm=1;
                           end
                           x1=curx(jj,1);
                           y1=cury(jj,1);
                           x2=curx(jj,2);
                           y2=cury(jj,2);
                           x3=curx(jj,3);
                           y3=cury(jj,3);
                           if NewPoint(eleto(jj,1),5)+NewPoint(eleto(mm,1),5)==0%%��Ԫ�͵�Ԫ���ǿ���
                               penn=penn_block;
                               pent=pent_block;
                               fric=fric_block;
                           else
                                penn=penn_platen;
                                pent=pent_platen;
                                fric=fric_platen;
                           end
                           %tic
                           for kk=1:3
                               hh=kk+1;
                               if hh>3
                                   hh=1;
                               end
                               x4=curx(mm,kk);  %%�жϸý����Ƿ���DFN���棬Interface(3*(ii-1)+kk,6)==1 %%%��dfn�Ľ���
                               y4=cury(mm,kk);
                               x5=curx(mm,hh);
                               y5=cury(mm,hh);   
                               %tic %6-7us���������棬����2-3 us
                               [havepoint1,pointt12]= line2triangle(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5);        
                               if havepoint1==1
                                   sst=length(pointt12);
                                   if sst==2
                                       havepoint1=0;
                                   end
                               end
                               %toc
                               %%%%----------------------------------------���˹��begin----------------------------------------------------%%%             
                               if havepoint1==1  %%%�����ཻ��ϵ��������Ϊpointt12,   1-2us
                                   if Interprop(eleto(mm,kk),2)==1%%dfn����
                                       penn=penn_DFN;
                                       pent=pent_DFN;
                                       fric=fric_DFN;
                                   end
                                   GaussPx=0.5*(pointt12(1)+pointt12(3));
                                   GaussPy=0.5*(pointt12(2)+pointt12(4));
                                   areajelemx= get3arean(x1,y1,x2,y2,x3,y3);%%%��Ԫjelemx�����
                                   area1= get3arean(GaussPx,GaussPy,x2,y2,x3,y3);
                                   area2= get3arean(GaussPx,GaussPy,x3,y3,x1,y1);
                                   N1=area1/areajelemx;
                                   N2=area2/areajelemx;
                                   N3=1.0-N1-N2;
                                   Ileng= get2lengn(x4,y4,x5,y5);%%%ielemx��Ԫkk����ĳ���
                                   ain= get2lengn(pointt12(1),pointt12(2),pointt12(3),pointt12(4));
                                   long4= get2lengn(GaussPx,GaussPy,x5,y5);
                                   N4=long4/Ileng;
                                   N5=1.0-N4;
                                   PG=27.0*N1*N2*N3;
                                   fn=penn*PG*ain;
                                   Fnx=fn*norx(mm,kk);%%%jelement����������������
                                   Fny=fn*nory(mm,kk);%%%jelement����������������
                                   VelGaussix=N4*volx(mm,kk)+N5*volx(mm,hh);
                                   VelGaussiy=N4*voly(mm,kk)+N5*voly(mm,hh);
                                   VelGaussjx=N1*volx(jj,1)+N2*volx(jj,2)+N3*volx(jj,3);
                                   VelGaussjy=N1*voly(jj,1)+N2*voly(jj,2)+N3*voly(jj,3);
                                   VelGaussjix=VelGaussjx-VelGaussix;  %%%jelemx��Ԫ�����ielemx��Ԫkk������ٶȣ����ڼ���ճ������Ħ�����ķ���
                                   %%����
                                   VelGaussjiy=VelGaussjy-VelGaussiy; 
                                   Directij=-VelGaussjix*nory(mm,kk)+VelGaussjiy*norx(mm,kk);  %%%�����жϷ�������ٶ�
                                   %fs=fn*tand(fric);
                                   %if abs(Directij)<=1e-10
                                   %    fs=0;
                                   %elseif abs(Directij)<=1e-4 
                                   %    fs=abs(Directij)/1e-4*fs;
                                   %end
                                   if sldis(icoup,3*(mm-1)+kk)<=100
                                       sldis(icoup,3*(mm-1)+kk)=sldis(icoup,3*(mm-1)+kk)+Directij*deltatime;%%%������������
                                       fs=sldis(icoup,3*(mm-1)+kk)*pent*Ileng;%%����δ֪
                                       %fsign=sign(fs);
                                       %fs=abs(fs);
                                       if abs(fs)>fn*tand(fric)
                                           fs=fs*abs(fn*tand(fric)/fs);
                                           sldis(icoup,3*(mm-1)+kk)=1000;
                                       end
                                   else  
                                        fs=fn*tand(fric);
                                   end
                                   if Directij<0
                                       Fsx=-fs*nory(mm,kk);%%%����jelemx����������
                                       Fsy=fs*norx(mm,kk);%%%����jelemx����������
                                   else
                                       Fsx=fs*nory(mm,kk);%%%����jelemx����������
                                       Fsy=-fs*norx(mm,kk);%%%����jelemx����������
                                   end
                    
                               %ro=3*mass(3*(jelem-1)+1,2)/areajelemx;
                               %damp=2*Ileng1*sqrt(E*ro);
                               %Fdam=-damp*VelGaussji;%%%����jelemx��Ԫ����������
                               %Fdam(3*(jelemx-1)+1,:)=-damp(3*(jelemx-1)+1)*VelGaussji;%%%����jelemx��Ԫ����������
%%----------------------------------------�������������------------begin------------------------------------------------------%%
                               %Fs=[0,0];
                                   %Ftotal=Fn+Fs;%+Fdam;%%�����ķ�����jelemx��Ԫ��
                                   ForceContact(eleto(jj,1),1)=ForceContact(eleto(jj,1),1)+N1*(Fnx+Fsx);%Ftotal(1);
                                   ForceContact(eleto(jj,1),2)=ForceContact(eleto(jj,1),2)+N1*(Fny+Fsy);%Ftotal(2);
                                   ForceContact(eleto(jj,2),1)=ForceContact(eleto(jj,2),1)+N2*(Fnx+Fsx);%Ftotal(1);
                                   ForceContact(eleto(jj,2),2)=ForceContact(eleto(jj,2),2)+N2*(Fny+Fsy);%Ftotal(2);
                                   ForceContact(eleto(jj,3),1)=ForceContact(eleto(jj,3),1)+N3*(Fnx+Fsx);%Ftotal(1);
                                   ForceContact(eleto(jj,3),2)=ForceContact(eleto(jj,3),2)+N3*(Fny+Fsy);%Ftotal(2);
                                   ForceContact(eleto(mm,kk),1)=ForceContact(eleto(mm,kk),1)-N4*(Fnx+Fsx);%Ftotal(1);
                                   ForceContact(eleto(mm,kk),2)=ForceContact(eleto(mm,kk),2)-N4*(Fny+Fsy);%Ftotal(2);
                                   ForceContact(eleto(mm,hh),1)=ForceContact(eleto(mm,hh),1)-N5*(Fnx+Fsx);%Ftotal(1);
                                   ForceContact(eleto(mm,hh),2)=ForceContact(eleto(mm,hh),2)-N5*(Fny+Fsy);%Ftotal(2);
%%%-----------------------------------------�������������------------end------------------------------------------------------%%            
                               end  
                           end
                           %toc
                       end
                       %toc
                   end
                   icoup=ZZ(icoup);
               end
           end
        end 