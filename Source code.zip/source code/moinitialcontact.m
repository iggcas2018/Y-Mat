%%%get initial contact
function [AAA,tint]=moinitialcontact
            global IE NewPoint CC ZZ Astore Interprop
            AAA=[];
            eleto=zeros(2,3);
            for ii=1:IE
                icoup=CC(ii);
                while icoup>0
                    if Astore(icoup)<0
                        ielem=ii;
                        jelem=-1-Astore(icoup);
                        jt=jelem;
                        for jj=1:2
                            for kk=1:3                   %%����Ԫ�Ľ���ת����������Ԫ�Ľ���/��
                                eleto(jj,kk)=3*(jt-1)+kk;%%eleto=[jelem��Ԫ��1���棬2���棬3���棻ielem��Ԫ��1���棬2���棬3����]
                            end                          %%
                            jt=ielem;
                        end
                        for jj=1:3   %%%������������ⷨ�ߵ�λ����
                            for kk=1:3
                                a1=eleto(1,jj);
                                a2=eleto(2,kk);
                                b1=a1+1;
                                b2=a2+1;
                                if mod(a1,3)==0
                                    b1=a1-2;
                                end
                                if mod(a2,3)==0
                                    b2=a2-2;
                                end
                                x1=NewPoint(a1,1);
                                y1=NewPoint(a1,2);
                                x2=NewPoint(b1,1);
                                y2=NewPoint(b1,2);
                                x11=NewPoint(a2,1);
                                y11=NewPoint(a2,2);
                                x22=NewPoint(b2,1);
                                y22=NewPoint(b2,2);
                                %Aout1=funs.get3outnormn(x1,y1,x2,y2);
                                %Aout2=funs.get3outnormn(x11,y11,x22,y22);
                                %if Aout1+Aout2==0
                                    if x1==x22 && y1==y22 
                                        if x2==x11 && y2==y11 
                                            A111=[a1,a2,1];%%%������ʼ�Ӵ�,��������Ϊ1
                                            if Interprop(a1,2)==1 %%%��dfn�Ľ���
                                                A111=[a1,a2,10];%%%������ʼ�Ӵ���DFN�Ӵ�Ϊ10
                                            end
                                            if isempty(AAA)
                                                AAA=A111;
                                            else
                                                AAA=[AAA;A111];
                                            end
                                        end
                                    end
                                %end
                            end
                        end                
                    end
                    icoup=ZZ(icoup);
                end
                tint=size(AAA);
                tint=tint(1);
            end
        end