%%%set of mechanics parameters of crack model
function name_inset=groupinter(C,fai,faires,ft,GI,GII,Pf,penn,pent)
            name_inset=[C,fai,faires,ft,GI,GII,Pf,penn,pent];
end