%%% whether two segments have intersection
function [t,a,b]=line2line(x1,y1,x2,y2,x3,y3,x4,y4)
            %x1=NewPoint0(7,1);y1=NewPoint0(7,2);x2=NewPoint0(8,1);y2=NewPoint0(8,2);x3=NewPoint0(1509,1);y3=NewPoint0(1509,2);
            %x4=NewPoint0(1507,1);y4=NewPoint0(1507,2);
            t=0;
            %intersection=[];
            a=[];
            b=[];
            xa1=0.5*(x1*(y2-y3)+x2*(y3-y1)+x3*(y1-y2));
            xa2=0.5*(x1*(y2-y4)+x2*(y4-y1)+x4*(y1-y2));
            xa3=0.5*(x1*(y3-y4)+x3*(y4-y1)+x4*(y1-y3));
            xa4=0.5*(x2*(y3-y4)+x3*(y4-y2)+x4*(y2-y3));
            Cauchy=1e-15;
            if abs(xa1)<=Cauchy || abs(xa2)<=Cauchy || abs(xa3)<=Cauchy || abs(xa4)<=Cauchy 
                t=0; 
            elseif xa1*xa2<0 && xa3*xa4<0
                t=1;
                m=abs(xa1)/(abs(xa1)+abs(xa2));
                a=m*(x4-x3)+x3;
                b=m*(y4-y3)+y3;
                %intersection=[a,b];
            end
end