%%%set of mechanics parameters of elements
function name_zset=groupzone(E,V,ro,C,fai,ft)
            name_zset=[E,V,ro,C,fai,ft];
end