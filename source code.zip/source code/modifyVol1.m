%%%modify velocity of loading elements in running
function modifyVol1(volyB)
            global Boundxy Vol IE NewPoint
            if Boundxy==1
                for i=1:3*IE
                     if NewPoint(i,5)==1  %%�ϼ��ظ� upper loading platen
                          Vol(i,2)=-volyB;
                          Vol(i,1)=0;
                     elseif NewPoint(i,5)==2 %%�¼��ظ� lower loading platen
                          Vol(i,2)=volyB;
                          Vol(i,1)=0;
                     end
                end
            end
end