%%% modify the contact information during running
function [CC,ZZ,Astore]=moNBSmodify(ncelx,ncely)
            global IE rr IXY Ecenter
            M=IE*(IE-1)/2;
            CC=-ones(1,IE);
            ZZ=zeros(1,M);
            Astore=zeros(1,M);
            nx=ncelx;
            ny=ncely;
            Y=-ones(1,IE);
            X=-ones(1,IE);
            AA=-ones(2,nx);
            BB=-ones(1,ny);%%%y-list first
            iheady=[0,0];
            iheadx=[0,0,0,0,0];
            diezone=1e-10;
            for i=1:M  
                ZZ(i)=i+1;
            end
            ZZ(M)=-1;
            counter=1; 
            for ie=1:IE    %%loop over all discrete elements
                iy=IXY(ie,2)+1;   %%%calculate intergerised y coordinates of its centre
                Y(ie)=BB(iy);   %%%place the discrete element onto a list... 
                BB(iy)=ie;      %%% for the corresponding row of cell, y-list
            end
            for ie=1:IE      %%%loop over all discrete elements
                iy=IXY(ie,2)+1;   %%%calculate intergerised y coordinates of its centre
                if BB(iy)<=IE   %%%if discrete element belongs to a new y-list
                    iheady(1)=BB(iy);
                    if iy==1
                        iheady(2)=-1;
                    else
                        iheady(2)=BB(iy-1);%%%�п��ܷ���B1(0)
                    end
                    if iheady(2)>IE
                        iheady(2)=iheady(2)-2*IE;
                    end
                    BB(iy)=BB(iy)+2*IE;   %%%mark the y-list as an old list and call it central y-list
                    for ihx=1:2
                        ielemy=iheady(ihx);
                        while ielemy>0
                            ix=IXY(ielemy,1)+1;
                            X(ielemy)=AA(ihx,ix);
                            AA(ihx,ix)=ielemy;
                            ielemy=Y(ielemy);
                        end
                    end
                    ielemy=iheady(1);
                    while ielemy>0
                        ix=IXY(ielemy,1)+1;
                        if AA(1,ix)<=IE
                            iheadx(1)=AA(1,ix);
                            iheadx(4)=AA(2,ix);
                            if nx==1
                                iheadx(2)=-1;
                                iheadx(3)=-1;
                                iheadx(5)=-1;
                            else
                                if ix ==1
                                    iheadx(2)=-1;
                                    iheadx(3)=AA(2,ix+1);
                                    iheadx(5)=-1;
                                elseif ix==nx
                                    iheadx(2)=AA(1,ix-1);
                                    iheadx(3)=-1;
                                    iheadx(5)=AA(2,ix-1);
                                else
                                    iheadx(2)=AA(1,ix-1);
                                    iheadx(3)=AA(2,ix+1);
                                    iheadx(5)=AA(2,ix-1);
                                end
                            end      
                            if iheadx(2)>IE
                                iheadx(2)=iheadx(2)-2*IE;
                            end
                            AA(1,ix)=AA(1,ix)+2*IE;%%%֮ǰ�޴���
                            ielemx=iheadx(1);
                            while ielemx>0
                                for j=1:5
                                    jelemx=iheadx(j);
                                    while jelemx>0
                                       if j~=1 || ielemx>jelemx
                                           %%%���нӴ��ж�
                                           imax=max(ielemx,jelemx);
                                           imin=min(ielemx,jelemx);
                               %%�Ƴ����ϸ����ԣ����Ҵ��³�ʼ����ʱ��û�б�Ҫ�Ƴ�����Ϊ���Ǵ��¼����
                               %icoup=CC(imax);
                               %jcoup=icoup;
                               %while icoup>0 && imin>0
                               %    if Astore(icoup)==-1-imin
                               %       % if (Ecenter(imax,1)-Ecenter(imin,1))^2+ (Ecenter(imax,2)-Ecenter(imin,2))^2>(rr(imax)+rr(imin)+diezone)^2 
                               %           ZZ(jcoup)=ZZ(icoup);
                               %           if jcoup==icoup
                               %              CC(imax)=ZZ(icoup);
                               %           end
                               %           ZZ(icoup)=counter;
                               %           counter=icoup;
                               %       % end
                               %        imin=-1;
                               %    end
                               %    jcoup=icoup;
                               %    icoup=ZZ(icoup);
                               %end
                               %%%�����½Ӵ�
                               %Ecent1=funs.get2Ecentern(imax);
                               %Ecent2=funs.get2Ecentern(imin);
                                           if imin>0  
                                               %if (Ecent1(1)-Ecent2(1))^2+ (Ecent1(2)-Ecent2(2))^2<(rr(imax)+rr(imin)+diezone)^2 %%%��֤jelemx��Ԫ��ielemx��Ԫ�п��ܽӴ�%4
                                               if (Ecenter(imax,1)-Ecenter(imin,1))^2+ (Ecenter(imax,2)-Ecenter(imin,2))^2<(rr(imax)+rr(imin)+diezone)^2 
                                                   icoup=counter;
                                                   if icoup>0
                                                       counter=ZZ(icoup); 
                                                       %ZZ(icoup)=CC(imax);%%�÷����Ǵ��������С��
                                                       %CC(imax)=icoup;
                                                       %Astore(icoup)=-1-imin;
                                                       ZZ(icoup)=CC(ielemx);%%�÷�����ԭʼ·�����з�����
                                                       CC(ielemx)=icoup;
                                                       Astore(icoup)=-1-jelemx;
                                                   end
                                               end
                                           end
                                       end
                                       jelemx=X(jelemx);
                                    end
                                end
                                ielemx=X(ielemx);
                            end
                        end
                        ielemy=Y(ielemy);
                    end
                    for ihx=1:2
                        ielemy=iheady(ihx);
                        while ielemy>0
                            ix=IXY(ielemy,1)+1;
                            AA(ihx,ix)=-1;
                            ielemy=Y(ielemy);
                        end
                    end
                end
            end

            for ie=1:IE
                iy=IXY(ie,2)+1;
                Y(ie)=BB(iy);
                BB(iy)=-1;
            end
end