function [K,G]=Young2Shear(E,v)   %%Convert elastic modulus and Poisson's ratio to shear modulus and bulk modulus
            K=1/3*E/(1-2*v);
            G=0.5*E/(1+v);
end