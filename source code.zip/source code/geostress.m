function gstress=geostress(sxx,syy,gradyxx,gradyyy)  %%apply the geostress to the model
          global IE NewPoint cavprop
          %sxx=-1e6; syy=0; gradyxx=1e6; gradyyy=0;
          gstress=zeros(3*IE,2);
          miny=min(NewPoint(:,2));
           for ii=1:IE
             if cavprop(ii)==0 
               a=3*(ii-1);
               x1=NewPoint(a+1,1);
               x2=NewPoint(a+2,1);
               x3=NewPoint(a+3,1);
               y1=NewPoint(a+1,2);
               y2=NewPoint(a+2,2);
               y3=NewPoint(a+3,2);
               n1x=y3-y2; n1y=x2-x3;
               n2x=y1-y3; n2y=x3-x1;
               n3x=y2-y1; n3y=x1-x2;
               TS1=sxx+gradyxx*((y1+y2+y3)/3.0 - miny);
               TS2=syy+gradyyy*((y1+y2+y3)/3.0 - miny);
               gstress(a+1,1)= -0.5*TS1*n1x;
               gstress(a+1,2)= -0.5*TS2*n1y;
               gstress(a+2,1)= -0.5*TS1*n2x;
               gstress(a+2,2)= -0.5*TS2*n2y;
               gstress(a+3,1)= -0.5*TS1*n3x;
               gstress(a+3,2)= -0.5*TS2*n3y;
             end
           end
end