%%% get damp
function damp=modamp(E_block,E_platen)
            global IE NewPoint mass 
            damp=zeros(IE,1);
            for ie=1:IE
                x1=NewPoint(3*(ie-1)+1,1);
                y1=NewPoint(3*(ie-1)+1,2);
                x2=NewPoint(3*(ie-1)+2,1);
                y2=NewPoint(3*(ie-1)+2,2);
                x3=NewPoint(3*(ie-1)+3,1);
                y3=NewPoint(3*(ie-1)+3,2);    
                Ileng2=get2lengn(x1,y1,x2,y2)+get2lengn(x2,y2,x3,y3)+get2lengn(x3,y3,x1,y1);
                Ileng2=Ileng2/3;
                area=get2arean(ie); 
                ro=3*mass(3*(ie-1)+1,2)/area;
                if NewPoint(3*ie,5)==0 %%%����
                    Evis=E_block;
                else
                    Evis=E_platen;
                end
                visdam=2*Ileng2*sqrt(Evis*ro);
                damp(ie)=visdam;
            end
        end