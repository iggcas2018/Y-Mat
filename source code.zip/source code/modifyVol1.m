function modifyVol1(volyB)  %%apply the velocities to the boundary
            global Vol IE NewPoint
            %if Boundxy==1
                for i=1:3*IE
                     if NewPoint(i,5)==1  
                          Vol(i,2)=-volyB;
                          Vol(i,1)=0;
                     elseif NewPoint(i,5)==2 
                          Vol(i,2)=volyB;
                          Vol(i,1)=0;
                     end
                end
            %end
end