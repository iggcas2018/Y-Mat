%%%initialize the procedure%%%
clear
clc  
%<------------------------------------read data--------------------------��% 
readata;
%<------------------------------------define and initialize global variables---------------------------��%
global IE NewPoint IXY rr mass Vol NewPoint0 plas U Acc gacce Modeca fst Ecenter crackmode 
global CC ZZ Astore Interprop AAA opi  sldis  MaxCon stres Funbal slldis Cauchy cavprop
Cauchy=1e-12;
[NewPoint,IE]= moget1NewPoint1(p,t,group,dfn,boundout);
Modeca=1;%%1 plain stress��other(e.g.,2) plain strain
sxx=0;syy=0;gradyxx=0;gradyyy=0;%%geostress
%%MaxCon=IE*(IE-1)/2;
MaxCon=IE*1e2;
sldis=zeros(MaxCon,6);
slldis=zeros(MaxCon,1);
stres=zeros(IE,7);
cavprop=zeros(IE,1); 
a1=0.63;b1=1.8;c1=6.0;
aa1=a1+b1;
U=zeros(3*IE,2);          
Vol=zeros(3*IE,2);     
Acc=zeros(3*IE,2);     
Funbal=zeros(3*IE,2); 
plas=zeros(IE,1);
gacce=0; %%gravity
opi=10000; %%output frequency
NewPoint0=NewPoint;
Ecenter= get2Ecentern;
Interprop= moint2;
load crackmode;
%<------------------------------------parameters of the model-------------------------------��%
block_zset= groupzone(5e10,0.25,2700,2e7,30,5e6);%/grouprop(E,v,ro,C,fai,ft)/%
block_inset= groupinter(2e7,26.5,10,5e6,5,50,5e11,5e11,30); %{groupinter(C,fai,faires,ft,GI,GII,Pf,penn,max_friction)}%
DFN1_inset= groupinter(2e7,26.5,10,5e6,2,20,5e11,5e11,30);
platen_zset= groupzone(2e11,0.3,7000,2e8,40,2e8);%/grouprop(E,v,ro,C,fai,ft)/%
platen_inset= groupinter(2e8,40,0,2e8,20,200,2e12,2e12,45); %{groupinter(C,fai,faires,ft,GI,GII,Pf,penn,max_friction)}%
Dmun_platen= chplpr(platen_zset(1),platen_zset(2));
mass= mogetmass(block_zset(3),platen_zset(3));
rr= getmaxr;
[IXY,ncelx,ncely]= get4rrn;
%%<------------------------------prepare to the calculation------------------------------------>%%
[CC,ZZ,Astore]= moNBSmodify(ncelx,ncely);
[AAA,tint]= moinitialcontact;
fst= fst_cal(tint,block_inset,DFN1_inset,platen_inset);
%%<------------------------------boundary conditions------------------------------------>%%
Gravity=mass*gacce;            %%%%%gravity
Fbound= mogetboundaryU(0,1,0,0);%%(loading platens,1(yes)/0��no),stress ��0��or displacement��1����x��y��

%%<------------------------------time step size-------------------------------------->%%
dt1= stepsize(block_zset(1),block_zset(2),block_zset(3),block_inset(8));
dt2= stepsize(platen_zset(1),platen_zset(2),platen_zset(3),platen_inset(8));
deltatime=min(dt1,dt2)/2.0;
clear dt1 dt2
%%<------------------------------set the total steps-------------------------------------->%%

Circle=100000; %%total step
count=0;
