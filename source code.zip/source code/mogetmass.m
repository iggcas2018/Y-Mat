function mass=mogetmass(dens_block,dens_platen)  %%get the mass matrix of all the elements
            global IE NewPoint
            mass=zeros(3*IE,2); 
            for ie=1:IE
                area=get2arean(ie);      
                if NewPoint(3*ie,5)==0
                    for jj=1:3
                        mass(3*(ie-1)+jj,2)=dens_block*area/3;
                    end
                elseif NewPoint(3*ie,5)==1 || NewPoint(3*ie,5)==2
                    for jj=1:3
                        mass(3*(ie-1)+jj,2)=dens_platen*area/3;
                    end
                end     
            end
end