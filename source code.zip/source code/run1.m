tic
for imain=1:Circle
    fdamp= modamp(block_zset(1),platen_zset(1));
    ffmun=getFdn(block_zset,platen_zset);
    gstress=geostress(sxx,syy,gradyxx,gradyyy);
    ForceJoint= mofracture(block_inset,platen_inset,DFN1_inset,a1,b1,c1);   
    if mod(imain,10)==0     
        Ecenter= get2Ecentern;
        rr= getmaxr;
        [IXY,ncelx,ncely]= get4rrn;
        [CC,ZZ,Astore]= moNBSmodify(ncelx,ncely);
    end
    ForceContact=calculatem(block_inset,platen_inset,DFN1_inset);  
    Funbal=ForceContact+ffmun+gstress+ForceJoint+Fbound+Gravity+fdamp;
    Acc=(Funbal)./[mass(:,2),mass(:,2)];
    Vol=Vol+Acc*deltatime;
    modifyVol1(0.05);
    U=Vol*deltatime; 
    NewPoint(:,[1 2])=NewPoint(:,[1 2])+U;  
    count=count+1;
    disp(['step:' num2str(count),'/',num2str(Circle)]);
    if mod(count,10000)==0
        abcd=count;
        save(num2str(abcd));
    end
    if count==500000  
        extran(1);
        exchangeAAA(1,tint); 
        NewPoint0=NewPoint;
        plas(:)=0;
        Vol(:)=0;
        num1=find(NewPoint0(:,5)==0,1,'last')+1;
        num2=find(NewPoint0(:,5)==1,1,'last');
        Funbal(num1:num2,1:2)=0;
        Gravity(num1:num2,2)=0;
        save(num2str(count+1));
    end
end
toc

