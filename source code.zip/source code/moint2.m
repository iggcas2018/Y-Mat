%%%the information of interface between two elements, the infomation
%%%including boundary interface and DFN inerface
function Interprop=moint2
            global IE NewPoint 
            Interprop=zeros(3*IE,2);
            for ii=1:IE
                for jj=1:3
                    kk=jj+1;
                    if kk>3
                        kk=1;
                    end
                    if NewPoint(3*(ii-1)+jj,3)==1&&NewPoint(3*(ii-1)+kk,3)==1
                        Interprop(3*(ii-1)+jj,1)=1;%%%���ڱ߽����
                    end
                    if NewPoint(3*(ii-1)+jj,4)==1&&NewPoint(3*(ii-1)+kk,4)==1
                        Interprop(3*(ii-1)+jj,2)=1;%%%����DFN����
                    end
                end
            end
end