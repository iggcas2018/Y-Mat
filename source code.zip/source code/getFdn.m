function ffmun=getFdn(block_zset,platen_zset)  %%calculate the deformation forces matrix of elements
       global stres IE NewPoint U plas Modeca cavprop
        ffmun=zeros(3*IE,2);
          E_block=block_zset(1);
          vv_block=block_zset(2);
          Cohe_inblock=block_zset(4);
          fric_inblock=block_zset(5);
          ft_inblock=block_zset(6);
          %Dmun_block= chplpr(E_block,vv_block);
          [Kmod1,Gmod1]= Young2Shear(E_block,vv_block);
          E_platen=platen_zset(1);
          vv_platen=platen_zset(2);
          Cohe_inplaten=platen_zset(4);
          fric_inplaten=platen_zset(5);
          ft_inplaten=platen_zset(6);
          %Dmun_platen= chplpr(E_platen,vv_platen);
          [Kmod2,Gmod2]= Young2Shear(E_platen,vv_platen);
        for ie=1:IE
            if cavprop(ie)==0
               if NewPoint(3*ie,5)==0 
                   %Dmun=Dmun_block;
                   vv=vv_block;
                   Kmod=Kmod1;
                   Gmod=Gmod1;
                   fric=fric_inblock;
                   Cohe=Cohe_inblock;
                   ft=ft_inblock;
               else
                   %Dmun=Dmun_platen;
                   vv=vv_platen;
                   Kmod=Kmod2;
                   Gmod=Gmod2;
                   fric=fric_inplaten;
                   Cohe=Cohe_inplaten;
                   ft=ft_inplaten;
               end
               x21=NewPoint(3*(ie-1)+2,1)-NewPoint(3*(ie-1)+1,1);
               y21=NewPoint(3*(ie-1)+2,2)-NewPoint(3*(ie-1)+1,2);
               x31=NewPoint(3*(ie-1)+3,1)-NewPoint(3*(ie-1)+1,1);
               y31=NewPoint(3*(ie-1)+3,2)-NewPoint(3*(ie-1)+1,2);
               x32=NewPoint(3*(ie-1)+3,1)-NewPoint(3*(ie-1)+2,1);
               y32=NewPoint(3*(ie-1)+3,2)-NewPoint(3*(ie-1)+2,2);
               area=x21*y31-x31*y21; 
               %BB=[-y32 0 y31 0 -y21 0;
                %   0 x32 0 -x31 0 x21;
                 %  x32 -y32 -x31 y31 x21 -y21]/area;
               %uu=[U(3*(ie-1)+1,1:2),U(3*(ie-1)+2,1:2),U(3*(ie-1)+3,1:2)]';
               %K = transpose(B)*D*B*area;
               stra1=-y32*U(3*(ie-1)+1,1)+y31*U(3*(ie-1)+2,1)-y21*U(3*(ie-1)+3,1);
               stra2=x32*U(3*(ie-1)+1,2)-x31*U(3*(ie-1)+2,2)+x21*U(3*(ie-1)+3,2);
               stra3=x32*U(3*(ie-1)+1,1)-y32*U(3*(ie-1)+1,2)-x31*U(3*(ie-1)+2,1)+y31*U(3*(ie-1)+2,2)+x21*U(3*(ie-1)+3,1)-y21*U(3*(ie-1)+3,2);
              
               %%* --- trial elastic stresses --- *%%
               e1_ = Kmod + Gmod*4/3;
               e2_ = Kmod - Gmod*2/3;
               g2_ = Gmod;
               stnEd11= stra1/area;
               stnEd22= stra2/area;
               stnEd12=stra3/area;
               %stnEd23=0;
               %stnEd13=0;
               %%%plain strain
               if Modeca==1
                   stnEd33= -vv/(1-vv)*(stra1+stra2);
               else
               %%%plain strain
                   stnEd33= 0;
               end
               sigmax=stres(ie,1);
               sigmay=stres(ie,2);
               sigmaz=stres(ie,3);
               tauxy=stres(ie,4);
               sigmax=sigmax+stnEd11 * e1_ + (stnEd22 + stnEd33) * e2_;
               sigmay=sigmay+(stnEd11 + stnEd33) * e2_ + stnEd22 * e1_;
               sigmaz=sigmaz+(stnEd11 + stnEd22) * e2_ + stnEd33 * e1_;
               tauxy=tauxy+ stnEd12* g2_;
               %stres(ie,1)=stres(ie,1)+stnEd11 * e1_ + (stnEd22 + stnEd33) * e2_;
               %stres(ie,2)=stres(ie,2)+(stnEd11 + stnEd33) * e2_ + stnEd22 * e1_;
               %stres(ie,3)=stres(ie,3)+(stnEd11 + stnEd22) * e2_ + stnEd33 * e1_;
               %stres(ie,4)=stres(ie,4)+ stnEd12* g2_;
               %stres(ie,5)=stres(ie,5)+ stnEd13* g2_;
               %stres(ie,6)=stres(ie,6)+ stnEd23* g2_;
               %sigmax=stres(ie,1);
               %sigmay=stres(ie,2);
               %sigmaz=stres(ie,3);
               %tauxy=stres(ie,4);
               sqrtpara=sqrt((sigmax-sigmay)^2+4*tauxy^2);
               sigma1=0.5*(sigmax+sigmay+sqrtpara);
               sigma2=0.5*(sigmax+sigmay-sqrtpara);
               midmat=[sigma1,sigma2,sigmaz]; 
               [sig1,si1]=min(midmat);
               [sig3,si3]=max(midmat);
               si2=6-si1-si3;
               if sigma1==sigma2 && sigma2==sigmaz
                   si1=1;
                   si2=2;
                   si3=3;
               end
               sig2=midmat(si2);
               nph_  = (1.0 + sind(fric)) / (1.0 - sind(fric));
               csn_  = 2.0 * Cohe * sqrt(nph_);
               if fric_inblock
                   apex = Cohe * cosd(fric) / sind(fric);
                   ft =  min(ft,apex);
               end
               %rsin =  sin(dilation);
               %rsin=0;
               %rnps_ = (1.0 + rsin) / (1.0 - rsin);
               %rnps_=1;
               bisc_ = sqrt(1.0 + nph_*nph_) + nph_;
               ra = e1_ -  e2_;
          	   rb = -ra;
	           rd = ra - rb * nph_;
	           sc1_ = ra / rd;
	           sc3_ = rb / rd;
	           sc2_ = 0;
	           e21_ = e2_ / e1_;      
               fsurf = sig1 - nph_ * sig3 + csn_;
               tsurf = ft - sig3;
               pdiv = -tsurf + (sig1 - nph_ * ft + csn_) * bisc_;
               pla=plas(ie);
               if (fsurf < 0.0 && pdiv < 0.0) 
                   if pla==0 || pla==1
                       pla = 1;%%shearnow
                   elseif pla==2  
                       pla=3;%%tensile failure followed by shear failure
                   end
	               sig1 =sig1- fsurf * sc1_;
	               sig2 =sig2- fsurf * sc2_;
	               sig3 =sig3- fsurf * sc3_;
               elseif (tsurf < 0.0 && pdiv > 0.0) 
                   if pla==0 || pla==2
                       pla=2;
                   elseif pla==1
                       pla=4;%%shear failure followed by tension failure
                   end
	               tco = e21_ * tsurf;
                   sig1 =sig1+ tco;
                   sig2 =sig2+ tco;
                   sig3 =ft;
               end
               plas(ie)=pla;
               midmat(si1)=sig1;
               midmat(si2)=sig2;
               midmat(si3)=sig3;
               if sqrtpara==0 %sigmax==sigmay && tauxy==0 ||
                   theta=0;
               else
                   theta1=0.5*asin(2*tauxy/sqrtpara);
                   if sigmay<=sigmax
                       theta=theta1;
                   elseif sigmay>sigmax
                       if tauxy>0
                           theta=pi/2-theta1;
                       elseif tauxy<0
                           theta=-pi/2-theta1; 
                       else
                           theta=pi/2;
                       end
                   end
               end
               sigma1=midmat(1);
               sigma2=midmat(2);
               sigmax=0.5*(sigma1+sigma2)+0.5*(sigma1-sigma2)*cos(2*theta);
               sigmay=0.5*(sigma1+sigma2)-0.5*(sigma1-sigma2)*cos(2*theta);
               tauxy=0.5*(sigma1-sigma2)*sin(2*theta);
               if tauxy==0
                   tauxy=0;
               end  
               stres(ie,1)=sigmax;
               stres(ie,2)=sigmay;
               stres(ie,3)=midmat(3);
               stres(ie,4)=tauxy;
               stres(ie,5)=sigma1;
               stres(ie,6)=sigma2;
               stres(ie,7)=theta;
               ffmun(3*(ie-1)+1,1)=0.5*(sigmax*(y31-y21)+tauxy*(x21-x31));
               ffmun(3*(ie-1)+1,2)=0.5*(tauxy*(y31-y21)+sigmay*(x21-x31));
               ffmun(3*(ie-1)+2,1)=0.5*(-sigmax*y31+tauxy*x31);
               ffmun(3*(ie-1)+2,2)=0.5*(-tauxy*y31+sigmay*x31);
               ffmun(3*(ie-1)+3,1)=0.5*(sigmax*y21-tauxy*x21);
               ffmun(3*(ie-1)+3,2)=0.5*(tauxy*y21-sigmay*x21);
            end
        end
end
%toc