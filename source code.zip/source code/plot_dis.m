%%%show the result of displacement(x-disp,y-disp,disp)
function plot_dis(xys_index)%%plot_dis(��ʾ˭��λ�ƣ����κ��λ�þ��󣬱���ǰ��λ�þ���)
            global NewPoint NewPoint0 IE count
            figure ;
            colordef white
            axis equal ;
            axis off ;
            %xys_index=1;
            switch xys_index
                case 1
                    title=strcat('x-disp',num2str(count));
                case 2
                    title=strcat('y-disp',num2str(count));
                case 3
                    title=strcat('disp',num2str(count));
            end
            %set( gcf, 'NumberTitle', 'off' ) ;
            set( gcf, 'Name', title) ;
            %Pnp=find(NewPoint(:,5)==0, 1, 'last' );
            Pnp=3*IE;
            zcon=NewPoint(1:Pnp,1:2)-NewPoint0(1:Pnp,1:2);%x,y
            zcons=sqrt(zcon(:,1).^2+zcon(:,2).^2);%total
            xdisMin=min(zcon(:,1));%%xdis
            xdisMax=max(zcon(:,1));
            ydisMin=min(zcon(:,2));%ydis
            ydisMax=max(zcon(:,2));
            sdisMin=0;
            sdisMax=max(zcons);%%dis
            if xys_index==1
                disMin=xdisMin;
                disMax=xdisMax;
                CcMatrix=zcon(:,1);
            elseif xys_index==2
                disMin=ydisMin;
                disMax=ydisMax;
                CcMatrix=zcon(:,2);
            else
                disMin=sdisMin;
                disMax=sdisMax;
                CcMatrix=zcons;
            end
            caxis( [disMin, disMax] ) ;
            colormap( 'Jet' ) ;
            for ie=1:Pnp/3
                x = [NewPoint(3*(ie-1)+1,1);NewPoint(3*(ie-1)+2,1);NewPoint(3*(ie-1)+3,1)];
                y = [NewPoint(3*(ie-1)+1,2);NewPoint(3*(ie-1)+2,2);NewPoint(3*(ie-1)+3,2)];
                c = [CcMatrix(3*(ie-1)+1);CcMatrix(3*(ie-1)+2);CcMatrix(3*(ie-1)+3)] ;
                set( patch( x, y, c ), 'EdgeColor', 'interp' ) ;
            end
            yTick = disMin:(disMax-disMin)/10:disMax ;
            Label = cell( 1, length(yTick) );
            for i=1:length(yTick)
                Label{i} = sprintf( '%.5fmm', yTick(i)*1e3) ;
            end
            set( colorbar('vert'), 'YTick', yTick, ...
            'YTickLabelMode','Manual','YTickLabel',Label) ;
end