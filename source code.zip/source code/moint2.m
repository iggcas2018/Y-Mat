function Interprop=moint2  %%Find the boundary or DFN interface in the interface
            global IE NewPoint 
            Interprop=zeros(3*IE,2);
            for ii=1:IE
                for jj=1:3
                    kk=jj+1;
                    if kk>3
                        kk=1;
                    end
                    if NewPoint(3*(ii-1)+jj,3)==1&&NewPoint(3*(ii-1)+kk,3)==1
                        Interprop(3*(ii-1)+jj,1)=1;%%%belong to boundary
                    end
                    if NewPoint(3*(ii-1)+jj,4)==1&&NewPoint(3*(ii-1)+kk,4)==1
                        Interprop(3*(ii-1)+jj,2)=1;%%%belong to DFN
                    end
                end
            end
end