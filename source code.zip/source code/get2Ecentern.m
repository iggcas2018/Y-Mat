%%%get the coordinates of the center point of all elements
function Ecenter=get2Ecentern
            global NewPoint IE
            Ecenter=zeros(IE,2);
            for ii=1:IE 
                Ecenter(ii,1)=(NewPoint(3*(ii-1)+1,1)+NewPoint(3*(ii-1)+2,1)+NewPoint(3*(ii-1)+3,1))/3;
                Ecenter(ii,2)=(NewPoint(3*(ii-1)+1,2)+NewPoint(3*(ii-1)+2,2)+NewPoint(3*(ii-1)+3,2))/3;
            end
end