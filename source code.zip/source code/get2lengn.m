function lenginter2=get2lengn(x1,y1,x2,y2) %%calculate the length of an edge of a triangle
            lx=x2-x1;
            ly=y2-y1;
            lenginter2=sqrt(lx^2+ly^2);
end