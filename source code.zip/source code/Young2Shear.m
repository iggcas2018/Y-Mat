%%%translate Young modulus and possion ratio to bulk and shear
function [K,G]=Young2Shear(E,v)
            K=1/3*E/(1-2*v);
            G=0.5*E/(1+v);
end