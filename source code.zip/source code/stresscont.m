function stresscont(xyt_index)  %%plot the stress contour
global NewPoint Ecenter stres
figure
hold on
axis equal
axis off
switch xyt_index
    case 1
      title='xstress contour';
    case 2
      title='ystress contour';
    case 3
      title='tangential stress contour';
end
set( gcf, 'NumberTitle', 'off' ) ;
set( gcf, 'Name', title ) ;
Pnp=find(NewPoint(:,5)==0, 1, 'last' );
XX=Ecenter(1:Pnp/3,1);
YY=Ecenter(1:Pnp/3,2);
if xyt_index==1
    ZZ=stres(1:Pnp/3,1);
elseif xyt_index==2
    ZZ=stres(1:Pnp/3,2);
else
    ZZ=stres(1:Pnp/3,4);
end
[X,Y]=meshgrid(linspace(min(XX),max(XX),100),linspace(min(YY),max(YY),100));
Z = griddata(XX,YY,ZZ,X,Y);
contour(X,Y,Z,100,'k','linewidth',1)
end



