function exchangeAAA(groupid,tint) %%%code for excavation, to free the interaction of joint elements in excavation area
    global AAA cavprop
    for ii=1:tint
        J1=AAA(ii,1);%%����1 
        J2=AAA(ii,2);%%����2
        %ss0=AAA(i,3);%%%%��������ֵ
        k1=ceil(J1/3);
        k2=ceil(J2/3);
        if cavprop(k1)==groupid || cavprop(k2)==groupid
            AAA(ii,3)=AAA(ii,3)-10;
        end
    end
end