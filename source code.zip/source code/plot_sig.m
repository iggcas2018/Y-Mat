function plot_sig(xys_index)%%Plot the result of stress (eg. x-component, y-component, shear stress, min principal stress, max principal stress)   
            global NewPoint IE papercolor2 Xray stres
            figure ;
            axis equal ;
            axis off ;
            %xys_index=4;
            switch xys_index
                case 1
                    title='sxx';
                case 2
                    title='syy';
                case 3
                    title='sxy';
                case 4
                    title='minprin';
                case 5
                    title='maxprin';   
            end
            set( gcf, 'NumberTitle', 'off' ) ;
            set( gcf, 'Name', title ) ;
            
            Pnp=find(NewPoint(:,5)==0, 1, 'last' );
            Pnp=3*IE;
            
            xstrMin=min(stres(1:Pnp/3,1));%%sxx
            xstrMax=max(stres(1:Pnp/3,1));
            ystrMin=min(stres(1:Pnp/3,2));%syy
            ystrMax=max(stres(1:Pnp/3,2));
            sstrMin=min(stres(1:Pnp/3,4));%%sxy
            sstrMax=max(stres(1:Pnp/3,4));
            MinstrMin=min(stres(1:Pnp/3,5));%minprin
            MinstrMax=max(stres(1:Pnp/3,5));
            MaxstrMin=min(stres(1:Pnp/3,6));%maxprin
            MaxstrMax=max(stres(1:Pnp/3,6));
            if xys_index==1
                strMin=xstrMin;
                strMax=xstrMax;
                CcMatrix=stres(:,1);
            elseif xys_index==2
                strMin=ystrMin;
                strMax=ystrMax;
                CcMatrix=stres(:,2);
            elseif xys_index==3
                strMin=sstrMin;
                strMax=sstrMax;
                CcMatrix=stres(:,4);
            elseif xys_index==4
                strMin=MinstrMin;
                strMax=MinstrMax;
                CcMatrix=stres(:,5);
            else
                strMin=MaxstrMin;
                strMax=MaxstrMax;
                CcMatrix=stres(:,6);
            end
            %strMin=-10e6;
            %strMax=10e6;
            caxis( [strMin, strMax] ) ;
           % colormap( Xray ) ;
            for ie=1:Pnp/3
                x = [NewPoint(3*(ie-1)+1,1);NewPoint(3*(ie-1)+2,1);NewPoint(3*(ie-1)+3,1)];
                y = [NewPoint(3*(ie-1)+1,2);NewPoint(3*(ie-1)+2,2);NewPoint(3*(ie-1)+3,2)];
                c = [CcMatrix(ie);CcMatrix(ie);CcMatrix(ie)] ;
                set( patch( x, y, c ), 'EdgeColor', 'interp' ) ;
            end
            yTick = strMin:(strMax-strMin)/10:strMax ;
            Label = cell( 1, length(yTick) );
            for i=1:length(yTick)
                Label{i} = sprintf( '%.3fMPa', yTick(i)*1e-6) ;
            end
            set( colorbar('vert'), 'YTick', yTick, ...
            'YTickLabelMode','Manual','YTickLabel',Label) ;
end