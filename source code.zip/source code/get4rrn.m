function [IXY,ncelx,ncely]=get4rrn  %%calculate data for NBS method
            global IE NewPoint rr Ecenter
            rr1=max(rr);
            dd=2*rr1;
            Xmax=max(NewPoint(:,1));
            Xmin=min(NewPoint(:,1));
            Ymax=max(NewPoint(:,2));
            Ymin=min(NewPoint(:,2));
            %%%��ÿ����Ԫ���������������� 
            IXY=zeros(IE,2);
            for ie=1:IE
                IXY(ie,1)=floor((Ecenter(ie,1)-Xmin)/dd);
                IXY(ie,2)=floor((Ecenter(ie,2)-Ymin)/dd);
            end
            ncelx=ceil((Xmax-Xmin)/dd);
            ncely=ceil((Ymax-Ymin)/dd);
end