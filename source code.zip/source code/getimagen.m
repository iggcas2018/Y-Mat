%%%plot the model using current coordinate and fractures
function getimagen(tint)
            global NewPoint Interprop IE AAA
            figure
            kkkk=0;
            for ii=1:IE
                kkkk=kkkk+1;
                hold on  
                H_F2=fill([NewPoint(3*(ii-1)+1,1),NewPoint(3*(ii-1)+2,1),...
                        NewPoint(3*(ii-1)+3,1)],[NewPoint(3*(ii-1)+1,2),...
                        NewPoint(3*(ii-1)+2,2),NewPoint(3*(ii-1)+3,2)],[0.6,0.5,0.4],'edgecolor','k');%%[1 128/255 26/255]
                set(H_F2,{'LineStyle'},{'none'})
                %title(num2str(kkkk),'Position',Ecenter(ii,[1,2]))
                %text(Ecenter(ii,1),Ecenter(ii,2),num2str(kkkk),'Color','k','Fontsize',10)
            end 
            axis equal
            axis off
            %colordef black
            %xis([0,1,0,1])
            for ii=1:tint
                J1=AAA(ii,1);%%����1 
                J2=AAA(ii,2);%%����2
                ss=AAA(ii,3);%%%%��������ֵ
                K1=J1+1;
                K2=J2+1;
                if mod(J1,3)==0
                    K1=J1-2;
                end
                if mod(J2,3)==0
                    K2=J2-2;
                end
                if ss==2   %%%�����ƻ�
                    plot([NewPoint(J1,1) NewPoint(K1,1)],[NewPoint(J1,2) NewPoint(K1,2)],'r','LineWidth',1)
                    plot([NewPoint(J2,1) NewPoint(K2,1)],[NewPoint(J2,2) NewPoint(K2,2)],'r','LineWidth',1)
                end
                if ss==3   %%%�����ƻ�
                    plot([NewPoint(J1,1) NewPoint(K1,1)],[NewPoint(J1,2) NewPoint(K1,2)],'g','LineWidth',1)
                    plot([NewPoint(J2,1) NewPoint(K2,1)],[NewPoint(J2,2) NewPoint(K2,2)],'g','LineWidth',1)
                end
                if ss==4   %%%����ƻ�,�Լ�Ϊ��
                    plot([NewPoint(J1,1) NewPoint(K1,1)],[NewPoint(J1,2) NewPoint(K1,2)],'y','LineWidth',1)
                    plot([NewPoint(J2,1) NewPoint(K2,1)],[NewPoint(J2,2) NewPoint(K2,2)],'y','LineWidth',1)
                end
                if ss==5   %%%����ƻ�,����Ϊ��
                    plot([NewPoint(J1,1) NewPoint(K1,1)],[NewPoint(J1,2) NewPoint(K1,2)],'b','LineWidth',1)
                    plot([NewPoint(J2,1) NewPoint(K2,1)],[NewPoint(J2,2) NewPoint(K2,2)],'b','LineWidth',1)
                end
            end
            %%%��DFN
            for ii=1:IE
               for jj=1:3
                   if Interprop(3*(ii-1)+jj,2)==1
                       plot([Interface(3*(ii-1)+jj,1),Interface(3*(ii-1)+jj,3)],[Interface(3*(ii-1)+jj,2),Interface(3*(ii-1)+jj,4)],'r','LineWidth',3)
                   end
               end
            end
end
        % print -painters -dpdf -r600 test.pdf 