function extran(groupid)  %%code for excavation, set the excavation area by it's group number
   global NewPoint IE Vol cavprop Gravity
   %delt=1000;
   for ii=1:IE 
       a=3*(ii-1);
       if NewPoint(a+1,5)==groupid %%group's id
           cavprop(ii)=1;
           for jj=1:3
               for kk=1:2
                 Vol(a+jj,kk)=0;
                 Gravity(a+jj,kk)=0;
               end
           end
       end
   end       
end