%%%decide the time step size by Young modulus, possion ratio and density
function deltatime=stepsize(E,v,ro)
            global NewPoint IE
            [Kmod,Gmod]=Young2Shear(E,v);
            Cp=sqrt((Kmod+Gmod*4/3)/ro);
            deltax=zeros(IE,1);
            for ie=1:IE
                x1=NewPoint(3*(ie-1)+1,1);
                y1=NewPoint(3*(ie-1)+1,2);
                x2=NewPoint(3*(ie-1)+2,1);
                y2=NewPoint(3*(ie-1)+2,2);
                x3=NewPoint(3*(ie-1)+3,1);
                y3=NewPoint(3*(ie-1)+3,2);    
                deltax1=get2lengn(x1,y1,x2,y2)+get2lengn(x2,y2,x3,y3)+get2lengn(x3,y3,x1,y1);
                area=get2arean(ie);
                %areaii=get2arean(x1,y1,x2,y2,x3,y3);
                deltax(ie)=area/deltax1;
            end
            deltax=min(deltax);
            deltatime=deltax/Cp;              %%%ʱ��ѡ��
            order1=floor(log10(deltatime));
            resti=deltatime/10^order1;
            deltatime=5.0*floor(resti)*10^(order1-1);
            %deltatime=5.0*10^(order1-1);
end