output files included:

   (1) "10000.mat" is the result data at step 10000;
   (2) "100000.mat" is the result data at step 100000;
   (3) "Brazil model.tif" is the simulation model;
   (4) "failure mode.fig" and "failure mode.tif" show the failure mode of the model in different formats;
   (5) "xdisp.tif" shows the x-displacement cloud at the 100,000th time step;
   (6) "ystress.tif" shows y-stress cloud at the 100,000th time step;
   (7) "xstresscont.tif" shows the x-stress contour at the 10,000th time step.

 Note: Files with the suffix .fig need to be opened with matlab.
