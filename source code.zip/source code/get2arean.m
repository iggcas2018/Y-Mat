%%%get element area based on the element id
function S=get2arean(ie)
            global NewPoint
            x1 = NewPoint(3*(ie-1)+1,1);
            y1 = NewPoint(3*(ie-1)+1,2) ;
            x2 = NewPoint(3*(ie-1)+2,1);
            y2 = NewPoint(3*(ie-1)+2,2) ;
            x3 = NewPoint(3*(ie-1)+3,1);
            y3 = NewPoint(3*(ie-1)+3,2) ;
            S=(1/2)*(x1*y2+x2*y3+x3*y1-x1*y3-x2*y1-x3*y2);
end