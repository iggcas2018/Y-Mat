function getimagen(tint,gridshow) %%plot the model using current coordinate and fractures
            global NewPoint Interprop IE AAA crackmode cavprop
            figure
            kkkk=0;
            for ii=1:IE
              if cavprop(ii)==0 
                kkkk=kkkk+1;
                hold on 
                H_F2=fill([NewPoint(3*(ii-1)+1,1),NewPoint(3*(ii-1)+2,1),...
                        NewPoint(3*(ii-1)+3,1)],[NewPoint(3*(ii-1)+1,2),...
                        NewPoint(3*(ii-1)+2,2),NewPoint(3*(ii-1)+3,2)],[0.65,0.75,0.85],'edgecolor','k');%[0.6 0.5 0.4],[0.52 0.42 0.32]
                if gridshow==0
                    set(H_F2,{'LineStyle'},{'none'})
                end
                %title(num2str(kkkk),'Position',Ecenter(ii,[1,2]))
                %text(Ecenter(ii,1),Ecenter(ii,2),num2str(kkkk),'Color','k','Fontsize',10)
              end
            end
            axis equal
            axis off
            %colordef black
            %xis([0,1,0,1])
            colormap(crackmode);
            for ii=1:tint
                J1=AAA(ii,1);%%joint 1
                J2=AAA(ii,2);%%joint 2
                ss=AAA(ii,3);%%%%Interface attribute value
                K1=J1+1;
                K2=J2+1;
                if mod(J1,3)==0
                    K1=J1-2;
                end
                if mod(J2,3)==0
                    K2=J2-2;
                end
                
                if ss>=2 && ss<=3 
                    a=(ss-2)*63+1;
                    if a<=32.5
                        a=floor(a);
                    else
                       a= ceil(a);
                    end
                    plot([NewPoint(J1,1) NewPoint(K1,1)],[NewPoint(J1,2) NewPoint(K1,2)],'color',crackmode(a,:),'LineWidth',1)
                    plot([NewPoint(J2,1) NewPoint(K2,1)],[NewPoint(J2,2) NewPoint(K2,2)],'color',crackmode(a,:),'LineWidth',1)
                end
            end
            %%%draw DFN
            for ii=1:IE
               for jj=1:3
                   kk=jj+1;
                   if kk>3
                       kk=1;
                   end
                   if Interprop(3*(ii-1)+jj,2)==1
                       %plot([NewPoint(3*(ii-1)+jj,1),NewPoint(3*(ii-1)+kk,1)],[NewPoint(3*(ii-1)+jj,2),NewPoint(3*(ii-1)+kk,2)],'r','LineWidth',3)
                   end
               end
            end
end