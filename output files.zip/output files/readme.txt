output files included:

   (1) 50000.mat is the result data at step 50000 (Fig.1) ;
   (2) 100000.mat is the result data at step 100000 (Fig.2);
   (3) 50000.fig is a picture including failue trajectories at step 50000 (Fig.3);
   (4) xdisp_50000.fig is a picture that shows x-displacement cloud (Fig.4);
   (5) ystress_50000.fig is a picture that shows y-stress cloud (Fig.5); 
   (6) crack_50000.pdf show the same result as Fig.3 (Fig.6);
   (7) xdisp_50000.pdf show the same result as Fig.4 (Fig.7);
   (8) ystress50000.pdf show the same result as Fig.5 (Fig.8);

The results including (1)-(5) need to be opened by MATLAB. 
