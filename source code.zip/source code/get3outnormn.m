function [nx,ny]=get3outnormn(x1,y1,x2,y2)  %%calculate the outnormal of an edge of a triangle
            nx=y2-y1;
            ny=x1-x2;
            b=get2lengn(x1,y1,x2,y2);
            nx=nx/b;
            ny=ny/b;
end