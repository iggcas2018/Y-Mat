%%% Relative positional relationship between point and triangle
function tt=inoutriangle(x1,y1,x2,y2,x3,y3,x4,y4)
            %x1=NewPoint0(1,1);y1=NewPoint0(1,2);x2=NewPoint0(2,1);y2=NewPoint0(2,2);x3=NewPoint0(3,1);y3=NewPoint0(3,2);
            %x4=NewPoint0(7,1);y4=NewPoint0(7,2);
            %x1=NewPoint(7,1);y1=NewPoint(7,2);x2=NewPoint(8,1);y2=NewPoint(8,2);x3=NewPoint(9,1);y3=NewPoint(9,2);
            %x4=NewPoint(1509,1);y4=NewPoint(1509,2);
            l1=x2-x1;m1=y2-y1;o1=x4-x1;p1=y4-y1;
            l2=x3-x2;m2=y3-y2;o2=x4-x2;p2=y4-y2;
            l3=x1-x3;m3=y1-y3;o3=x4-x3;p3=y4-y3;
            ab1=l1*p1-m1*o1;
            ab2=l2*p2-m2*o2;
            ab3=l3*p3-m3*o3;
            Cauchy=1e-15;
            if abs(ab1)<Cauchy || abs(ab2)<Cauchy || abs(ab3)<Cauchy 
               if abs(ab1)<Cauchy
                   ab1=0;
               elseif abs(ab2)<Cauchy
                   ab2=0;
               else
                   ab3=0;
               end
            end
            if ab1*ab2*ab3==0
                tt=2;%�������α߽���
                if ab1*ab2<0 ||ab1*ab3<0 ||ab2*ab3<0
                    tt=3;
                end
            elseif ab1>0 && ab2>0 && ab3>0
                tt=1;%�������ε��ڲ�
            else
                tt=3;%�������ε��ⲿ
            end 
        end