function ForceContact=calculatem(block_inset,platen_inset,DFN1_inset)   %%calculate contact force
global IE NewPoint Vol  CC ZZ Astore Interprop sldis  Cauchy cavprop %vsldis
 penn_block=block_inset(8); 
 pent_block=block_inset(9);
 fric_block=block_inset(2);
 penn_platen=platen_inset(8);
 pent_platen=platen_inset(9);
 fric_platen=platen_inset(2);
 penn_DFN=DFN1_inset(8);
 pent_DFN=DFN1_inset(9);
 fric_DFN=DFN1_inset(2); 
 ForceContact=zeros(3*IE,2);
 vola=zeros(1,2);
 eleto=zeros(2,3);
 curx=zeros(2,3);
 cury=zeros(2,3);
 norx=zeros(2,3);
 nory=zeros(2,3);
 volx=zeros(2,3);
 voly=zeros(2,3);
 small= Cauchy;
 nsmall=-Cauchy;
 %big=1e15;
 %pp=zeros(1,10);
 ss=zeros(1,10);
 fx=zeros(1,3);
 fy=zeros(1,3);
 dd=zeros(2,3,3);
 %d2sldis=zeros(1,6);
for ii=1:IE 
     icoup=CC(ii);
      while icoup>0
       if Astore(icoup)<0
           icontact=-1;
           ielem=ii;
           jelem=-1-Astore(icoup);
           jt=jelem;
         if cavprop(ii)==0 && cavprop(jt)==0
          for jj=1:2
            for kk=1:3
               eleto(jj,kk)=3*(jt-1)+kk;
            end
            jt=ielem;
          end
          %d2sldis=sldis(icoup,:);
          for jj=1:2
            for kk=1:3
                curx(jj,kk)=NewPoint(eleto(jj,kk),1);
                cury(jj,kk)=NewPoint(eleto(jj,kk),2);
                volx(jj,kk)=Vol(eleto(jj,kk),1);
                voly(jj,kk)=Vol(eleto(jj,kk),2);
            end
          end
          for jj=1:2
            vola(jj)=(curx(jj,2)-curx(jj,1))*(cury(jj,3)-cury(jj,1))-(cury(jj,2)-cury(jj,1))*(curx(jj,3)-curx(jj,1)); %%%%vol��ֵ�������������
            for kk=1:3
              hh=kk+1; 
              if hh>3
                  hh=1;
              end
              norx(jj,kk)=cury(jj,hh)-cury(jj,kk);
              nory(jj,kk)=curx(jj,kk)-curx(jj,hh);
            end
          end
          for jj=1:2
              mm=jj+1;
              if mm>2
                  mm=1;
              end
              for kk=1:3
                  for ll=1:3
                     dd(jj,kk,ll)=((curx(mm,ll)-curx(jj,kk))*norx(mm,ll)+(cury(mm,ll)-cury(jj,kk))*nory(mm,ll))/vola(mm); 
                  end
              end
          end
          %%%%%%%%* main loop *
          icoupID=0;   
          if NewPoint(eleto(1,1),5)==NewPoint(eleto(2,1),5)
             if NewPoint(eleto(1,1),5)==0
                penn=penn_block;
                pent=pent_block;
                fric=fric_block;
             else 
                penn=penn_platen;
                pent=pent_platen;
                fric=fric_platen;
             end
          else
             penn=penn_block;
             pent=pent_block;
             fric=fric_block;
          end
          for jj=1:2
            mm=jj+1;
            if mm>2
                mm=1;
            end
            for kk=1:3
                fx(kk)=0;
                fy(kk)=0;
            end

            for kk=1:3
              icoupID=icoupID+1;
              ll=kk+1;
              if ll>3
                  ll=1;
              end
              if Interprop(eleto(jj,kk),2)==1%%dfn����
                  penn=penn_DFN;
                  pent=pent_DFN;
                  fric=fric_DFN;
              end
              
              a1=dd(jj,kk,1);%%[it][in][0];
              a2=dd(jj,kk,2);%%[it][in][1];
              a3=dd(jj,kk,3);%%[it][in][2];
              b1=dd(jj,ll,1);%%[it][jn][0];
              b2=dd(jj,ll,2);%%[it][jn][1];
              b3=dd(jj,ll,3);%%[it][jn][2];
              c1=dd(mm,1,kk);%%[jt][0][in];
              c2=dd(mm,2,kk);%%[jt][1][in];
              c3=dd(mm,3,kk);%%[jt][2][in];
              %%%%%%* check if contact */
              if((((c1>nsmall)&&(c2>nsmall)&&(c3>nsmall))|| ((c1<small)&&(c2<small)&&(c3<small)))||...
                 (((a1<small)&&(b1<small))||((a2<small)&&(b2<small))||((a3<small)&&(b3<small))))
              else
                icontact=jj;
                %%/* domain of contact */
                smin=0.0; smax=1.0;
                if((a1<0.0)&&(b1>small))
                    smin=max(smin,(a1/(a1-b1)));
                end
                if((a2<0.0)&&(b2>small))
                    smin=max(smin,(a2/(a2-b2)));
                end
                if((a3<0.0)&&(b3>small))
                    smin=max(smin,(a3/(a3-b3)));
                end
                if((a1>small)&&(b1<0.0))
                    smax=min(smax,(a1/(a1-b1)));
                end
                if((a2>small)&&(b2<0.0))
                    smax=min(smax,(a2/(a2-b2)));
                end
                if((a3>small)&&(b3<0.0))
                    smax=min(smax,(a3/(a3-b3)));
                end
                if(smax>smin)
                  ss(1)=smin;
                  ss(2)=smax;
                  ain= ss(2)-ss(1);%*Ileng;
                  N5 = 0.5*(ss(1)+ss(2));
                  N3 = ((a1*(1.0-N5)) + (b1*N5));
                  N1 = ((a2*(1.0-N5)) + (b2*N5));
                  N2 = ((a3*(1.0-N5)) + (b3*N5));
                  PG=27.0*N1*N2*N3;
                  fn=penn*PG*ain;
                  N4=1-N5;
                  vrelx = (N3*volx(mm,3)+N1*volx(mm,1)+N2*volx(mm,2))-...
                          (N4*volx(jj,kk)+N5*volx(jj,ll));
                  vrely = (N3*voly(mm,3)+N1*voly(mm,1)+N2*voly(mm,2))-...
                          (N4*voly(jj,kk)+N5*voly(jj,ll));
                  vrel = -vrelx*nory(jj,kk) + vrely*norx(jj,kk);
                  inta=abs(vrel);%/Ileng);
                  if sldis(icoup,icoupID)==0 || sldis(icoup,icoupID)==1
                     if inta<1e-10
                         fs=0;
                         sldis(icoup,icoupID)=0;
                     elseif inta>=1e-10 && inta<=8e-5
                         fs=inta/(8e-5)*tand(pent)*fn;%fs=(inta-1e-10)/(5e-4-1e-10)*tand(pent)*fn;
                         sldis(icoup,icoupID)=1;
                     else
                         fs=tand(fric)*fn;
                         sldis(icoup,icoupID)=2;
                     end
                  elseif sldis(icoup,icoupID)==2         
                     fs=tand(fric)*fn;
                     if inta<1e-10
                         fs=0;
                         sldis(icoup,icoupID)=0;
                     end                      
                  end
                  if vrel>0
                      fs=-fs;
                  end
                  fnx=fn*norx(jj,kk)-fs*nory(jj,kk);
                  fny=fn*nory(jj,kk)+fs*norx(jj,kk);
                  %%%%/* update total force */
                  fx(kk)=fx(kk)-fnx*N4;
                  fy(kk)=fy(kk)-fny*N4;
                  fx(ll)=fx(ll)-fnx*N5;
                  fy(ll)=fy(ll)-fny*N5;
                end
              end
            end
            if(icontact==jj) %%%%/* update nodal forces  */
              for kk=1:3
                ForceContact(eleto(jj,kk),1)=ForceContact(eleto(jj,kk),1)+fx(kk);
                ForceContact(eleto(jj,kk),2)=ForceContact(eleto(jj,kk),2)+fy(kk);
                ll=kk+1;
                if ll>3
                    ll=1;
                end
                for uu=1:3
                  ForceContact(eleto(mm,kk),1)=ForceContact(eleto(mm,kk),1)-fx(uu)*dd(jj,uu,ll);
                  ForceContact(eleto(mm,kk),2)=ForceContact(eleto(mm,kk),2)-fy(uu)*dd(jj,uu,ll);
                end
              end
            end
          end
         end
       end
       icoup=ZZ(icoup);
      end
end
end