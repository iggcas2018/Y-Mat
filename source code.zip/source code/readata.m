%%%read data from excel file
file_in='test1.xlsx';
sheet_in='test1';  
p=xlsread(file_in,sheet_in,'A:B');%%node
t=xlsread(file_in,sheet_in,'D:F');%%element
dfn=xlsread(file_in,sheet_in,'H:H');%%DFN info.
boundout=xlsread(file_in,sheet_in,'G:G');%%boundary info.
group=xlsread(file_in,sheet_in,'I:I');%%group info.
clear file_in
clear sheet_in