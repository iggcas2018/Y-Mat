%%% data preparation, such as the total number of elements, initial-
%%% coodinates of elements, boundary elements, group infomation, et al.
function [NewPoint,IE]=moget1NewPoint1(p,t,group,dfn,boundout)
            IE=size(t,1);
            IE=int32(IE);
            NewPoint=zeros(3*IE,5);%%1x,2y,3�߽�,4DFN��,5���
            DFNPoint=dfn;
            BoundPoint=boundout;
            Dz=size(dfn);
            Bz=size(BoundPoint);
            for ii=1:IE
            %%%NewPoint(3*(ii-1)+jj,kk)=p(t(ii,jj),kk);%%���У�ii=ȡ1��IE��jjȡ1:3��kkȡ1:2,%a(ismember(a(:,1),b),
                for jj=1:3
                    NewPoint(3*(ii-1)+jj,1)=p(t(ii,jj),1);
                    NewPoint(3*(ii-1)+jj,2)=p(t(ii,jj),2);
                    NewPoint(3*(ii-1)+jj,5)=group(ii);%%�õ����ڵ���ţ�0����Ʒ��1��2�Ǽ��ذ��
                end
                for mm=1:3
                    poid=3*(ii-1)+mm;
                    for pp=1:Dz
                        if DFNPoint(pp)==t(ii,mm)
                            NewPoint(poid,4)=1;%%��������DFN
                        end
                    end
                    for qq=1:Bz
                       if BoundPoint(qq)==t(ii,mm)
                           NewPoint(poid,3)=1;%%���ڱ߽��
                       end
                    end
                end
            end
end