        function [NewPoint,IE]=moget1NewPoint1(p,t,group,dfn,boundout) 
        %%%Prepare for the information of nodes, elements, boundary nodes, DFN nodes, and groups.
            IE=size(t,1);
            IE=int32(IE);
            NewPoint=zeros(3*IE,5);%%(x coordinate,y coordinate,boundary type,DFN,group number)
            DFNPoint=dfn;
            BoundPoint=boundout;
            Dz=size(dfn);
            Bz=size(BoundPoint);
            for ii=1:IE
                a=3*(ii-1);
                for jj=1:3
                    NewPoint(a+jj,1)=p(t(ii,jj),1);
                    NewPoint(a+jj,2)=p(t(ii,jj),2);
                    NewPoint(a+jj,5)=group(ii);
                end
                for mm=1:3
                    poid=a+mm;
                    for pp=1:Dz
                        if DFNPoint(pp)==t(ii,mm)
                            NewPoint(poid,4)=1;
                        end
                    end
                    for qq=1:Bz
                       if BoundPoint(qq)==t(ii,mm)
                           NewPoint(poid,3)=1;
                       end
                    end
                end
            end
        end