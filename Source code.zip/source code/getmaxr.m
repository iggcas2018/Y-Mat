%%%get the half-length of cell
function rr=getmaxr
            global NewPoint IE Ecenter
            rr=zeros(IE,1);
            for ie=1:IE
                re=zeros(1,3);
                Ecent1=Ecenter(ie,1);
                Ecent2=Ecenter(ie,2);
                for jj=1:3
                    r1=NewPoint(3*(ie-1)+jj,1)-Ecent1;
                    r2=NewPoint(3*(ie-1)+jj,2)-Ecent2;
                    re(jj)=sqrt(r1^2+r2^2);
                end
                rr(ie)=max(re);
            end
end