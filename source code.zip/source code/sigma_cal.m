%%%get deformation forces matrix
function [ffmun,sigmaxy]=sigma_cal(block_zset,platen_zset)
          global IE NewPoint NewPoint0 Vol damp  plas Modeca geoexist sxx syy count opi  d1sdel dpsem
          ffmun=zeros(3*IE,2);
          sigmaxy=zeros(IE,6);
          E_block=block_zset(1);
          vv_block=block_zset(2);
          Cohe_inblock=block_zset(4);
          fric_inblock=block_zset(5);
          ft_inblock=block_zset(6);
          Dmun_block= chplpr(E_block,vv_block);
          [Kmod1,Gmod1]= Young2Shear(E_block,vv_block);
          E_platen=platen_zset(1);
          vv_platen=platen_zset(2);
          Cohe_inplaten=platen_zset(4);
          fric_inplaten=platen_zset(5);
          ft_inplaten=platen_zset(6);
          Dmun_platen= chplpr(E_platen,vv_platen);
          [Kmod2,Gmod2]= Young2Shear(E_platen,vv_platen);
           for ie=1:IE
               %tic %%1-2us���ȽϽӽ�1
               if NewPoint(3*ie,5)==0 %%%����
                   Dmun=Dmun_block;
                   vv=vv_block;
                   Kmod=Kmod1;
                   Gmod=Gmod1;
                   fric=fric_inblock;
                   Cohe=Cohe_inblock;
                   ft=ft_inblock;
               else
                   Dmun=Dmun_platen;
                   vv=vv_platen;
                   Kmod=Kmod2;
                   Gmod=Gmod2;
                   fric=fric_inplaten;
                   Cohe=Cohe_inplaten;
                   ft=ft_inplaten;
               end
               x21=NewPoint(3*(ie-1)+2,1)-NewPoint(3*(ie-1)+1,1)';
               y21=NewPoint(3*(ie-1)+2,2)-NewPoint(3*(ie-1)+1,2)';
               x31=NewPoint(3*(ie-1)+3,1)-NewPoint(3*(ie-1)+1,1)';
               y31=NewPoint(3*(ie-1)+3,2)-NewPoint(3*(ie-1)+1,2)';
               x021=NewPoint0(3*(ie-1)+2,1)-NewPoint0(3*(ie-1)+1,1)';
               y021=NewPoint0(3*(ie-1)+2,2)-NewPoint0(3*(ie-1)+1,2)';
               x031=NewPoint0(3*(ie-1)+3,1)-NewPoint0(3*(ie-1)+1,1)';
               y031=NewPoint0(3*(ie-1)+3,2)-NewPoint0(3*(ie-1)+1,2)';
               vx21=Vol(3*(ie-1)+2,1)-Vol(3*(ie-1)+1,1);
               vy21=Vol(3*(ie-1)+2,2)-Vol(3*(ie-1)+1,2);
               vx31=Vol(3*(ie-1)+3,1)-Vol(3*(ie-1)+1,1);
               vy31=Vol(3*(ie-1)+3,2)-Vol(3*(ie-1)+1,2);
               %Fimun=[x021 x031;y021 y031];
               %Fcmun=[x21 x31;y21 y31];
               %Lcmun=[vx21 vx31;vy21 vy31];
               %Fmun=Fcmun/Fimun;
               %Lmun=Lcmun/Fcmun;
               %tic
               di1=(x021*y031-x031*y021);
               dc1=(x21*y31-x31*y21);
               a1=(x21*y031-x31*y021)/di1;
               b1=(x31*x021-x21*x031)/di1;
               c1=(y21*y031-y31*y021)/di1;
               d1=(y31*x021-y21*x031)/di1;
               va1=(vx21*y31-vx31*y21)/dc1;
               vb1=(vx31*x21-vx21*x31)/dc1;
               vc1=(vy21*y31-vy31*y21)/dc1;
               vd1=(vy31*x21-vy21*x31)/dc1;
               %Fmun=[a1 b1;c1 d1];
               %Lmun=[va1 vb1;vc1 vd1];
               %Fmun=[x21*y031-x31*y021 x31*x021-x21*x031;y21*y031-y31*y021 y31*x021-y21*x031]/(x021*y031-x031*y021);
               %Lmun=[vx21*y31-vx31*y21 vx31*x21-vx21*x31;vy21*y31-vy31*y21 vy31*x21-vy21*x31]/(x21*y31-x31*y21);
               %Bmun=Fmun*Fmun';
               %Bmun=[a1^2+b1^2 a1*c1+b1*d1;a1*c1+b1*d1 c1^2+d1^2 ];
               %Dmunstrain=0.5*(Lmun+Lmun');
               %Dmunstrain=[va1 0.5*(vb1+vc1);0.5*(vb1+vc1) vd1];
               ksc=damp(ie);
               emax=sqrt(((a1^2+b1^2+c1^2+d1^2)+sqrt((a1^2+b1^2-c1^2-d1^2)^2+4*(a1*c1+b1*d1)*(a1*c1+b1*d1)))*0.5);
               emax=max(1,emax);
               if d1sdel(ie)>-1e-10
                   d1sdel(ie)=max(d1sdel(ie),(emax-1.0)/dpsem);
               end
               %Emun=0.5*(Bmun-[1 0;0 1]);
               %Emun=0.5*[a1^2+b1^2-1 a1*c1+b1*d1;a1*c1+b1*d1 c1^2+d1^2-1 ];
               a2=0.5*(a1^2+b1^2-1);
               b2=0.5*(a1*c1+b1*d1);
               d2=0.5*(c1^2+d1^2-1);
               %Emun=[a2 b2;b2 d2];
               %sigmamun=Dmun*[Emun(1,1);Emun(2,2);Emun(1,2)]+ksc*[Dmunstrain(1,1);Dmunstrain(2,2);Dmunstrain(1,2)];
               sigmax=Dmun(1,1)*a2+Dmun(1,2)*d2+ksc*va1;
               sigmay=Dmun(2,1)*a2+Dmun(2,2)*d2+ksc*vd1;
               tauxy=Dmun(3,3)*b2+ksc*(vb1+vc1)*0.5;
               %toc
               %if plas(ie)==0
               %tic  %%10-11us
               %sigmax=sigmamun(1);
               %sigmay=sigmamun(2);
               %tauxy=sigmamun(3);
               sqrtpara=sqrt((sigmax-sigmay)^2+4*tauxy^2);
               sigma1=0.5*(sigmax+sigmay+sqrtpara);
               sigma2=0.5*(sigmax+sigmay-sqrtpara);
               if Modeca==1 %%%ƽ��Ӧ��
                   sigmaz=0;
               else        %%%ƽ��Ӧ��
                   sigmaz=vv*(sigmax+sigmay);
               end
               midmat=[sigma1,sigma2,sigmaz]; 
               [sig1,si1]=min(midmat);
               [sig3,si3]=max(midmat);
               si2=6-si1-si3;
               if sigma1==sigma2 && sigma2==sigmaz
                   si1=1;
                   si2=2;
                   si3=3;
               end
               sig2=midmat(si2);
               e1_ = Kmod + Gmod*4/3;
               e2_ = Kmod - Gmod*2/3;
               %g2_ = Gmod*2.0;
               nph_  = (1.0 + sind(fric)) / (1.0 - sind(fric));
               csn_  = 2.0 * Cohe * sqrt(nph_);
               if fric_inblock
                   apex = Cohe * cosd(fric) / sind(fric);
                   ft =  min(ft,apex);
               end
               %rsin =  sin(dilation);
               %rsin=0;
               %rnps_ = (1.0 + rsin) / (1.0 - rsin);
               %rnps_=1;
               bisc_ = sqrt(1.0 + nph_*nph_) + nph_;
               ra = e1_ -  e2_;
          	   rb = -ra;
	           rd = ra - rb * nph_;
	           sc1_ = ra / rd;
	           sc3_ = rb / rd;
	           sc2_ = 0;
	           e21_ = e2_ / e1_;      
               fsurf = sig1 - nph_ * sig3 + csn_;
               tsurf = ft - sig3;
               pdiv = -tsurf + (sig1 - nph_ * ft + csn_) * bisc_;
               if (fsurf < 0.0 && pdiv < 0.0) 
                   if plas(ie)==0 || plas(ie)==1
                       plas(ie) = 1;%%״̬�����ڼ����ƻ�
                   elseif plas(ie)==2
                       plas(ie)=3;%%�����ƻ����м����ƻ�
                   end
	               sig1 =sig1- fsurf * sc1_;
	               sig2 =sig2- fsurf * sc2_;
	               sig3 =sig3- fsurf * sc3_;
               elseif (tsurf < 0.0 && pdiv > 0.0) 
                   if plas(ie)==0 || plas(ie)==2
                       plas(ie)=2;
                   elseif plas(ie)==1
                       plas(ie)=4;%%�ȼ��к������ƻ�
                   end
	               tco = e21_ * tsurf;
                   sig1 =sig1+ tco;
                   sig2 =sig2+ tco;
                   sig3 =ft;
               end
               midmat(si1)=sig1;
               midmat(si2)=sig2;
               midmat(si3)=sig3;
               if sqrtpara==0 %sigmax==sigmay && tauxy==0 ||
                   theta=0;
                   %fprintf('test1')
               else
                   theta1=0.5*asin(2*tauxy/sqrtpara);
                   if sigmay<=sigmax
                       theta=theta1;
                   elseif sigmay>sigmax
                       if tauxy>0
                           theta=pi/2-theta1;
                       elseif tauxy<0
                           theta=-pi/2-theta1; 
                       else
                           theta=pi/2;
                       end
                   end
               end
               sigma1=midmat(1);
               sigma2=midmat(2);
               sigmanorx=0.5*(sigma1+sigma2)+0.5*(sigma1-sigma2)*cos(2*theta);
               sigmanory=0.5*(sigma1+sigma2)-0.5*(sigma1-sigma2)*cos(2*theta);
               taunor=0.5*(sigma1-sigma2)*sin(2*theta);
               if tauxy==0
                   taunor=0;
               end
               %sigmamun=[sigmanorx;sigmanory;taunor];
               %toc
              %end
               %sigmaxy(ie,1:6)=[sigmamun;sigma1;sigma2;theta];
               %if mod(count,opi)==1
                   sigmaxy(ie,1)=sigmanorx;
                   sigmaxy(ie,2)=sigmanory;
                   sigmaxy(ie,3)=taunor;
                   sigmaxy(ie,4)=sigma1;
                   sigmaxy(ie,5)=sigma2;
                   sigmaxy(ie,6)=theta;
               %end
               %sigmaMun=[sigmamun(1) sigmamun(3);sigmamun(3) sigmamun(2)]; %%%ƽ��Ӧ��
               %Nmun1=[y31-y21,x21-x31]';
               %Nmun2=[-y31,x31]';
               %Nmun3=[y21,-x21]';
               %tic
               ffmun(3*(ie-1)+1,1)=0.5*(sigmanorx*(y31-y21)+taunor*(x21-x31));
               ffmun(3*(ie-1)+1,2)=0.5*(taunor*(y31-y21)+sigmanory*(x21-x31));
               ffmun(3*(ie-1)+2,1)=0.5*(-sigmanorx*y31+taunor*x31);
               ffmun(3*(ie-1)+2,2)=0.5*(-taunor*y31+sigmanory*x31);
               ffmun(3*(ie-1)+3,1)=0.5*(sigmanorx*y21-taunor*x21);
               ffmun(3*(ie-1)+3,2)=0.5*(taunor*y21-sigmanory*x21);
               %toc
               if geoexist==1
                   %sigmaGeo=[sxx 0;0 syy];
                   %str1=0.5*sigmaGeo*Nmun1;
                   %str2=0.5*sigmaGeo*Nmun2;
                   %str3=0.5*sigmaGeo*Nmun3;
                   ffmun(3*(ie-1)+1,1)=ffmun(3*(ie-1)+1,1)+0.5*sxx*(y21-y31);
                   ffmun(3*(ie-1)+1,2)=ffmun(3*(ie-1)+1,2)+0.5*syy*(x31-x21);
                   ffmun(3*(ie-1)+2,1)=ffmun(3*(ie-1)+2,1)+0.5*sxx*y31;
                   ffmun(3*(ie-1)+2,2)=ffmun(3*(ie-1)+2,2)-0.5*syy*x31;
                   ffmun(3*(ie-1)+3,1)=ffmun(3*(ie-1)+3,1)-0.5*sxx*y21;
                   ffmun(3*(ie-1)+3,2)=ffmun(3*(ie-1)+3,2)+0.5*syy*(x21);
               end
           end
end