%%%achieve initial matrix of cohesion
function fst=fst_cal(tint,block_inset,DFN1_inset,platen_inset)
            global NewPoint AAA
            fst=zeros(tint,1);
            Cohe_block=block_inset(1);
            Cohe_platen=platen_inset(1);
            Cohe_DFN=DFN1_inset(1);
            for i=1:tint
                J1=AAA(i,1);
                J2=AAA(i,2);
                ss0=AAA(i,3);
                a1=NewPoint(J1,5);
                a2=NewPoint(J2,5);
                if a1==a2
                   if a1==0
                       if ss0==1
                           fst(i)=Cohe_block;
                       elseif ss0==10
                           fst(i)=Cohe_DFN;
                       end
                   else
                       fst(i)=Cohe_platen;
                   end
                else
                    AAA(i,3)=0;
                end
            end
end