function deltatime=stepsize(E,v,ro,penn)  %%get the time step size of the model
            global NewPoint IE mass
            [Kmod,Gmod]=Young2Shear(E,v);
            Cp=sqrt((Kmod+Gmod*4/3)/ro);
            deltax=zeros(IE,1);
            deltax1=zeros(IE,1);
            for ie=1:IE
                a=3*(ie-1);
                x21=NewPoint(a+2,1)-NewPoint(a+1,1);
                y21=NewPoint(a+2,2)-NewPoint(a+1,2);
                x31=NewPoint(a+3,1)-NewPoint(a+1,1);
                y31=NewPoint(a+3,2)-NewPoint(a+1,2);
                peri=sqrt(x21^2+y21^2)+sqrt(x31^2+y31^2)+sqrt((x31-x21)^2+(y31-y21)^2);
                area=x21*y31-x31*y21;
                deltax(ie)=0.5*area/peri;
                deltax1(ie)=2*sqrt(mass(a+1,2)*3/penn);
            end
            deltax=min(deltax)/Cp;
            deltax1=min(deltax1);
            deltatime=min(deltax,deltax1);
            order1=floor(log10(deltatime));
            resti=deltatime/10^order1;
            deltatime=5.0*floor(resti)*10^(order1-1);
end