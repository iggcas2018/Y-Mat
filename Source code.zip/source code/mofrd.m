%%Correct large deformation of the elements
function mofrd
global d1sdel NewPoint NewPoint0 Vol  IE
xtran=zeros(3,1);
ytran=zeros(3,1);
vxtran=zeros(3,1);
vytran=zeros(3,1);
xitran=zeros(3,1);
yitran=zeros(3,1); 
for ii=1:IE
    if d1sdel(ii,1)>=1.5
        d1sdel(ii,1)=-1;
       for jj=1:3
           xtran(jj)=NewPoint(3*(ii-1)+jj,1);
           ytran(jj)=NewPoint(3*(ii-1)+jj,2);
           vxtran(jj)=Vol(3*(ii-1)+jj,1);
           vytran(jj)=Vol(3*(ii-1)+jj,2);
           xitran(jj)=NewPoint0(3*(ii-1)+jj,1);
           yitran(jj)=NewPoint0(3*(ii-1)+jj,2);
       end
       xcen=(xtran(1)+xtran(2)+xtran(3))/3;
       ycen=(ytran(1)+ytran(2)+ytran(3))/3;
       vxcen=(vxtran(1)+vxtran(2)+vxtran(3))/3;
       vycen=(vytran(1)+vytran(2)+vytran(3))/3;
       xtran=xtran-xcen;
       ytran=ytran-ycen;
       vxtran=vxtran-vxcen;
       vytran=vytran-vycen;
       volc=(xtran(2)-xtran(1))*(ytran(3)-ytran(1))-(ytran(2)-ytran(1))*(xtran(3)-xtran(1));
       voli=(xitran(2)-xitran(1))*(yitran(3)-yitran(1))-(yitran(2)-yitran(1))*(xitran(3)-xitran(1));
       ratio=sqrt(min(1,voli/volc));
       for jj=1:3
          NewPoint(3*(ii-1)+jj,1)=xcen+xtran(jj)*ratio;
          NewPoint(3*(ii-1)+jj,2)=ycen+ytran(jj)*ratio;
          NewPoint0(3*(ii-1)+jj,1)=NewPoint(3*(ii-1)+jj,1);
          NewPoint0(3*(ii-1)+jj,2)=NewPoint(3*(ii-1)+jj,2);
          Vol(3*(ii-1)+jj,1)=vxcen;
          Vol(3*(ii-1)+jj,2)=vycen;
       end
    end
end
end