function Dmun=chplpr(E,v)  %%set the plain condition, Modeca=1 represents plain stress, other number represents plain strain
            global Modeca
            if Modeca==1 %%%plain stress
                Dmun=[1 v 0;v 1 0;0 0 (1-v)];
                Dmun=Dmun*E/(1-v^2);
            else        %%%plain strain
                Dmun=[1-v v 0;v 1-v 0;0 0 (1-2*v)];
                Dmun=Dmun*E/(1+v)*(1-2*v);
            end
end