function Fbound=mogetboundaryU(platen,stodi,xbou,ybou)  %%Set the stress boundary conditions or initialize the displacement boundary conditions
            global NewPoint IE  Vol Interprop
            Fbound=zeros(3*IE,2);  %%%initialize the stress boundary
            leftdownB=[min(NewPoint(:,1)),min(NewPoint(:,2))];%%%(left,down)boundary
            rightupB=[max(NewPoint(:,1)),max(NewPoint(:,2))];%%%(right,up)boundary
            diezone=1e-6; %%tolerance
            if stodi==0   %%stress boundary
                sigmax=xbou;   %%x
                sigmay=ybou;   %%y
            else          %%dispacement/velocity boundary
                volxB=xbou;    %%x
                volyB=ybou;    %%y
            end
            if platen==0   %%no platens
                if stodi==0
                %<--------------------apply stress boundary------------------------>%
                    for ie=1:IE
                        for j =1:3
                             if Interprop(3*(ie-1)+j,1)==1 
                                 h=j+1;
                                 if h>3
                                     h=1;
                                 end
                                 x1=NewPoint(3*(ie-1)+j,1);
                                 y1=NewPoint(3*(ie-1)+j,2);
                                 x2=NewPoint(3*(ie-1)+h,1);
                                 y2=NewPoint(3*(ie-1)+h,2);
                                 if (y1>=rightupB(2)-diezone && y2>=rightupB(2)-diezone)|| (y1<=leftdownB(2)+diezone && y2<=leftdownB(2)+diezone)
                                     Fbound(3*(ie-1)+j,:)=0.5*sigmay*[y1-y2,x2-x1];
                                     Fbound(3*(ie-1)+h,:)=0.5*sigmay*[y1-y2,x2-x1];
                                 end
                                 if (x1>=rightupB(1)-diezone && x2>=rightupB(1)-diezone)|| (x1<=leftdownB(1)+diezone && x2<=leftdownB(1)+diezone)
                                     Fbound(3*(ie-1)+j,:)=0.5*sigmax*[y1-y2,x2-x1];
                                     Fbound(3*(ie-1)+h,:)=0.5*sigmax*[y1-y2,x2-x1];
                                 end
                             end
                        end
                    end
                else 
                %%<-----------------------------------apply velocity boundary-------->
                    for ie=1:IE
                        for j=1:3
                            if NewPoint(3*(ie-1)+j,3)==1 
                                if NewPoint(3*(ie-1)+j,1)<=leftdownB(1)+diezone%% left
                                    Vol(3*(ie-1)+j,1)=volxB;
                                elseif NewPoint(3*(ie-1)+j,1)>=rightupB(1)-diezone %%right
                                    Vol(3*(ie-1)+j,1)=-volxB;
                                end
                                if NewPoint(3*(ie-1)+j,2)<=leftdownB(2)+diezone%%% down
                                    Vol(3*(ie-1)+j,2)=volyB;
                                elseif NewPoint(3*(ie-1)+j,2)>=rightupB(2)-diezone%%%up
                                    Vol(3*(ie-1)+j,2)=-volyB;
                                end
                            end
                        end
                    end 
                end
            else     %%apply velocity with platens
                for ie=1:IE
                    for j=1:3
                        if NewPoint(3*ie,5)==1  
                            %Vol(3*(ie-1)+j,1)=0;
                            Vol(3*(ie-1)+j,2)=-volyB;
                        elseif NewPoint(3*ie,5)==2 
                            %Vol(3*(ie-1)+j,1)=0;
                            Vol(3*(ie-1)+j,2)=volyB;
                        end
                    end
                end
            end
end