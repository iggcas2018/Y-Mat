function name_inset=groupinter(C,fai,faires,ft,GI,GII,Pf,penn,pent)  %%Input the mechanics parameters of crack model
            name_inset=[C,fai,faires,ft,GI,GII,Pf,penn,pent];
end