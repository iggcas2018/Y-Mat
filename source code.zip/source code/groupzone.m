function name_zset=groupzone(E,V,ro,C,fai,ft) %%Input mechanics parameters of elements
            name_zset=[E,V,ro,C,fai,ft];
end