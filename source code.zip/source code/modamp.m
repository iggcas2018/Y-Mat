function Fdamp=modamp(E_block,E_platen)  %%damping
           global IE NewPoint mass Vol  cavprop
            %E_block=block_zset(1);
            %E_platen=platen_zset(1);
            Fdamp=zeros(3*IE,1);
            for ie=1:IE
                if cavprop(ie)==0 
                   a=3*(ie-1);
                   if NewPoint(a+1,5)==0 %%%����
                      Evis=E_block;
                   else
                      Evis=E_platen;
                   end
                   x21=NewPoint(a+2,1)-NewPoint(a+1,1);
                   y21=NewPoint(a+2,2)-NewPoint(a+1,2);
                   x31=NewPoint(a+3,1)-NewPoint(a+1,1);
                   y31=NewPoint(a+3,2)-NewPoint(a+1,2);
                   
                   vx21=Vol(a+2,1)-Vol(a+1,1);
                   vy21=Vol(a+2,2)-Vol(a+1,2);
                   vx31=Vol(a+3,1)-Vol(a+1,1);
                   vy31=Vol(a+3,2)-Vol(a+1,2);
                   
                   dc1=x21*y31-x31*y21;
                   va1=(vx21*y31-vx31*y21)/dc1;
                   vb1=(vx31*x21-vx21*x31)/dc1;
                   vc1=(vy21*y31-vy31*y21)/dc1;
                   vd1=(vy31*x21-vy21*x31)/dc1;
                   Ileng=sqrt(x21^2+y21^2)+sqrt(x31^2+y31^2)+sqrt((x31-x21)^2+(y31-y21)^2);
                   %Ileng2=get2lengn(x1,y1,x2,y2)+get2lengn(x2,y2,x3,y3)+get2lengn(x3,y3,x1,y1);
                   Ileng=Ileng/3;
                   area2=x21*y31-x31*y21;
                   ro=6*mass(a+1,2)/area2;
                   
                   ksc=2*Ileng*sqrt(Evis*ro);
                   T11=ksc*va1;
                   T22=ksc*vd1;
                   T12=ksc*(vb1+vc1)*0.5;
                   Fdamp(a+1,1)=0.5*(T11*(y31-y21)+T12*(x21-x31));
                   Fdamp(a+1,2)=0.5*(T12*(y31-y21)+T22*(x21-x31));
                   Fdamp(a+2,1)=0.5*(-T11*y31+T12*x31);
                   Fdamp(a+2,2)=0.5*(-T12*y31+T22*x31);
                   Fdamp(a+3,1)=0.5*(T11*y21-T12*x21);
                   Fdamp(a+3,2)=0.5*(T12*y21-T22*x21);
                end
            end
 end