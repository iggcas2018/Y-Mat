      %%%get element area based on coordinates of three nodes 
      function S=get3arean(x1,y1,x2,y2,x3,y3)
            %AA=[1 x1 y1;1 x2 y2;1 x3 y3];
            %area=0.5*det(AA);
            S=(1/2)*(x1*y2+x2*y3+x3*y1-x1*y3-x2*y1-x3*y2);
      end