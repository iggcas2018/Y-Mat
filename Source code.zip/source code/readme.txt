Test data were generated using Gmsh (a meshing software).
They include nodes and elements infomation.
The data were saved in the Excel file named test1.xlsx in source code folder.