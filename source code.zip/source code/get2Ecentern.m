        function Ecenter=get2Ecentern  %%calculate the centers of all the elements
            global NewPoint IE cavprop
            Ecenter=zeros(IE,2);
            for ii=1:IE 
              if cavprop(ii)==0
                a=3*(ii-1);
                Ecenter(ii,1)=(NewPoint(a+1,1)+NewPoint(a+2,1)+NewPoint(a+3,1))/3;
                Ecenter(ii,2)=(NewPoint(a+1,2)+NewPoint(a+2,2)+NewPoint(a+3,2))/3;
              end
            end
        end