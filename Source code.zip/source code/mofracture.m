%%%calculate joint element force including crack model and DFN
function ForceJoint=mofracture(block_inset,platen_inset,DFN1_inset,a1,b1,c1)
            global IE NewPoint  fst AAA
            ForceJoint=zeros(3*IE,2);
            Pf_block=block_inset(7);%{groupinter(C,fai,faires,ft,GI,GII,Pf,penn)}%
            ft_block=block_inset(4);
            Cohe_block=block_inset(1);
            fric_block=block_inset(2);
            fricres_block=block_inset(3);
            GIfe_block=block_inset(5);
            GIIfe_block=block_inset(6);
            Pf_DFN=DFN1_inset(7);%{groupinter(C,fai,faires,ft,GI,GII,Pf,penn)}%
            ft_DFN=DFN1_inset(4);
            Cohe_DFN=DFN1_inset(1);
            fric_DFN=DFN1_inset(2);
            fricres_DFN=DFN1_inset(3);
            GIfe_DFN=DFN1_inset(5);
            GIIfe_DFN=DFN1_inset(6);
            Pf_platen=platen_inset(7);%{groupinter(C,fai,faires,ft,GI,GII,Pf,penn)}%
            ft_platen=platen_inset(4);
            Cohe_platen=platen_inset(1);
            fric_platen=platen_inset(2);
            fricres_platen=platen_inset(3);
            GIfe_platen=platen_inset(5);
            GIIfe_platen=platen_inset(6);
            tint=length(fst);
            for i=1:tint
                J1=AAA(i,1);%%����1 
                J2=AAA(i,2);%%����2
                ss0=AAA(i,3);%%%%��������ֵ
                K1=J1+1;
                K2=J2+1;
                if mod(J1,3)==0
                    K1=J1-2;
                end
                if mod(J2,3)==0
                    K2=J2-2;
                end
                if ss0==1 || ss0==10%%1����ͨ�Ӵ����id,10�ǵ�һ��DFN��id,AAA(i,1),AAA(i,2)�ֱ�Ϊ�����Ӵ��Ľ��棬�ڵ�ɷֱ�����Ϊ1,2,3,4
                    if NewPoint(J1,5)==0  %%��Ʒ�ڲ�
                        if ss0==1
                            Pf=Pf_block;
                            ft=ft_block;
                            Cohe=Cohe_block;
                            fric=fric_block;
                            fricres=fricres_block;
                            GIfe=GIfe_block;
                            GIIfe=GIIfe_block;
                        elseif ss0==10
                            Pf=Pf_DFN;
                            ft=ft_DFN;
                            Cohe=Cohe_DFN;
                            fric=fric_DFN;
                            fricres=fricres_DFN;
                            GIfe=GIfe_DFN;
                            GIIfe=GIIfe_DFN;
                        end
                    elseif  NewPoint(J1,5)==1 ||  NewPoint(J1,5)==2  %%���ظ��ڲ�
                            Pf=Pf_platen;
                            ft=ft_platen;
                            Cohe=Cohe_platen;
                            fric=fric_platen;
                            fricres=fricres_platen;
                            GIfe=GIfe_platen;
                            GIIfe=GIIfe_platen;
                    end                 
                    x1=NewPoint(J1,1);%%%����kk��ʼ��
                    y1=NewPoint(J1,2);%%%����kk��ʼ��
                    x2=NewPoint(K1,1);
                    y2=NewPoint(K1,2);
                    
                    x3=NewPoint(J2,1);%%%����ll��ʼ��
                    y3=NewPoint(J2,2);%%%����ll��ʼ��
                    x4=NewPoint(K2,1);%%%����ll��ֹ��
                    y4=NewPoint(K2,2);%%%����ll��ֹ�� 
                    e1x=0.5*(x2+x3-x1-x4);
                    e1y=0.5*(y2+y3-y1-y4);
                    hin=sqrt(e1x^2+e1y^2);
                    e1x=e1x/hin;%(hin+smallm);
                    e1y=e1y/hin;%(hin+smallm);%%����λ����e1,
                    s1=(y1-y4)*e1y+(x1-x4)*e1x;%%dot(e1,41)
                    s2=(y2-y3)*e1y+(x2-x3)*e1x;%%dot(e1,32)
                    o1=(y1-y4)*e1x-(x1-x4)*e1y;%%dot(e2,41)
                    o2=(y2-y3)*e1x-(x2-x3)*e1y;%%dot(e2,32)
                    fsj=fst(i);
                    op=2.0*hin*ft/Pf;
                    sp=2.0*hin*fsj/Pf;
                    %ot=max(2.0*op,3.0*GIf/ft);
                    %st=max(2.0*sp,3.0*GIf/fsj);
                    %ot=max(2.0*op,3.0*GIfe/ft);
                    %st=max(2.0*sp,3.0*GIIfe/fsj);
                    ot=max(1e-10,3.0*GIfe/ft);
                    st=max(1e-10,3.0*GIIfe/fsj);
                    for integ=1:3  %%Ŀ�Ľ����浥Ԫ�Ľڵ�����ĵ��Ȩƽ��
                        if ss0==1 || ss0==10
                            if integ==1
                                o=o1;
                                s=s1;
                            elseif integ==2
                                o=(o1+o2)/2.0;
                                s=(s1+s2)/2.0;
                            else
                                o=o2;
                                s=s2;
                            end
                            sabs=abs(s);
                            if o>op && sabs>sp    %%��DD
                                DD=sqrt(((o-op)/ot)*((o-op)/ot)+((sabs-sp)/st)*((sabs-sp)/st));
                            elseif o>op             
                                DD=(o-op)/ot;             
                            elseif sabs>sp          
                                DD=(sabs-sp)/st;   
                            else                      
                                DD=0.0;                  
                            end
                            if DD>=1.0 %%%�ƻ��ˣ�������ʽ�п����ǻ�ϡ�����������
                                if o>=op+ot && sabs>=sp+st
                                    ss0=40;%%����ƻ�
                                elseif  o>=op+ot
                                    ss0=2;%%���ƻ�
                                elseif sabs>=sp+st
                                    ss0=3;%%���ƻ�
                                else
                                    if o/(op+ot)>s/(sp+st)
                                        ss0=5;%%����һ�ֻ���ƻ��������������벻����
                                    else
                                        ss0=4;
                                    end
                                end
                                DD=1.0;
                            end
                            AAA(i,3)=ss0;
                            if ss0==1 || ss0==10 %%�����һͷ�����ƻ�����Ӧ��ֱ�����㣬�����ٽ��м��㡣
                                aa1=a1+b1;
                                fDD=1-(aa1-1)/aa1*exp(DD*(a1+c1*b1)/aa1/(1-aa1));
                                fDD=fDD*(a1*(1-DD)+b1*(1-DD)^c1);
                                if o<0.0
                                    sigman=2*o*ft/op;
                                elseif o>op
                                    sigman=fDD*ft;
                                else
                                    sigman=(2.0*o/op-(o/op)^2)*ft;
                                end
                                %%����Ħ������׼��
                                if Cohe>0.0
                                   if sigman>0  %%��Ӧ��
                                       fsj=Cohe;
                                   else         %%0Ӧ����ѹӦ��������
                                       fsj=Cohe-sigman*tand(fric);
                                   end
                                end
                                if sigman>0.0 && sabs>sp
                                    tau=fDD*fsj;
                                elseif sigman>0.0
                                    tau=(2.0*sabs/sp-(sabs/sp)^2)*fDD*fsj;
                                elseif sabs>sp
                                    tau=fDD*fsj-sigman*tand(fricres);
                                else
                                    tau=(2.0*sabs/sp-(sabs/sp)^2)*(fDD*fsj-sigman*tand(fricres));%%�ù�ʽ��fDDӦ����1��
                                end
                                fst(i)=fsj;
                                if s<0.0
                                    tau=-tau;
                                end
                                if integ==1 
                                    ForceJoint(J1,1)=ForceJoint(J1,1)-hin*(tau*e1x-sigman*e1y)/6.0;%%����1,4�ڵ��Ӧ��
                                    ForceJoint(J1,2)=ForceJoint(J1,2)-hin*(tau*e1y+sigman*e1x)/6;%%����1,4�ڵ��Ӧ��
                                    ForceJoint(K2,1)=ForceJoint(K2,1)+hin*(tau*e1x-sigman*e1y)/6;
                                    ForceJoint(K2,2)=ForceJoint(K2,2)+hin*(tau*e1y+sigman*e1x)/6;
                                end
                                if integ==2
                                    %%����1,4��2,3�ڵ��Ӧ��
                                    ForceJoint(J1,1)=ForceJoint(J1,1)-hin*(tau*e1x-sigman*e1y)/3.0;%%����1�ڵ��Ӧ��
                                    ForceJoint(J1,2)=ForceJoint(J1,2)-hin*(tau*e1y+sigman*e1x)/3.0;%%����1�ڵ��Ӧ��
                                    ForceJoint(K2,1)=ForceJoint(K2,1)+hin*(tau*e1x-sigman*e1y)/3.0;%%����4�ڵ��Ӧ��
                                    ForceJoint(K2,2)=ForceJoint(K2,2)+hin*(tau*e1y+sigman*e1x)/3.0;
                                    ForceJoint(J2,1)=ForceJoint(J2,1)+hin*(tau*e1x-sigman*e1y)/3.0;%%����3�ڵ��Ӧ��
                                    ForceJoint(J2,2)=ForceJoint(J2,2)+hin*(tau*e1y+sigman*e1x)/3.0;%%����3�ڵ��Ӧ��
                                    ForceJoint(K1,1)=ForceJoint(K1,1)-hin*(tau*e1x-sigman*e1y)/3.0;%%����2�ڵ��Ӧ��
                                    ForceJoint(K1,2)=ForceJoint(K1,2)-hin*(tau*e1y+sigman*e1x)/3.0;           
                                end
                                if integ==3
                                    %%����2,3�ڵ��Ӧ��
                                    ForceJoint(J2,1)=ForceJoint(J2,1)+hin*(tau*e1x-sigman*e1y)/6.0;%%����3�ڵ��Ӧ��
                                    ForceJoint(J2,2)=ForceJoint(J2,2)+hin*(tau*e1y+sigman*e1x)/6.0;%%����3�ڵ��Ӧ��
                                    ForceJoint(K1,1)=ForceJoint(K1,1)-hin*(tau*e1x-sigman*e1y)/6.0;%%����2�ڵ��Ӧ��
                                    ForceJoint(K1,2)=ForceJoint(K1,2)-hin*(tau*e1y+sigman*e1x)/6.0;    
                                end
                            end
                        end
                    end
                end
            end
end