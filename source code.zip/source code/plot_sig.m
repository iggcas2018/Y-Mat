%%%show the result of sigma (x-sig,y-sig,shear stress, min principal
%%%stress, max principal stress
function plot_sig(xys_index,sigmaxy)%%plot_dis(��ʾ˭��λ�ƣ����κ��λ�þ��󣬱���ǰ��λ�þ���)
            %%%������    
            global NewPoint IE 
            figure ;
            axis equal ;
            axis off ;
            %xys_index=2;
            switch xys_index
                case 1
                    title='x-stress';
                case 2
                    title='y-stress';
                case 3
                    title='shear stress';
                case 4
                    title='min principal stress';
                case 5
                    title='max principal stress';   
            end
            set( gcf, 'NumberTitle', 'off' ) ;
            set( gcf, 'Name', title ) ;
            %%%ȷ�����ֵ����Сֵ
            %Pnp=find(NewPoint(:,5)==0, 1, 'last' );
            Pnp=3*IE;
            xstrMin=min(sigmaxy(:,1));%%xdis
            xstrMax=max(sigmaxy(:,1));
            ystrMin=min(sigmaxy(:,2));%ydis
            ystrMax=max(sigmaxy(:,2));
            sstrMin=min(sigmaxy(:,3));%%xdis
            sstrMax=max(sigmaxy(:,3));
            MinstrMin=min(sigmaxy(:,4));%ydis
            MinstrMax=max(sigmaxy(:,4));
            MaxstrMin=min(sigmaxy(:,5));%ydis
            MaxstrMax=max(sigmaxy(:,5));
            if xys_index==1
                strMin=xstrMin;
                strMax=xstrMax;
                CcMatrix=sigmaxy(:,1);
            elseif xys_index==2
                strMin=ystrMin;
                strMax=ystrMax;
                CcMatrix=sigmaxy(:,2);
            elseif xys_index==3
                strMin=sstrMin;
                strMax=sstrMax;
                CcMatrix=sigmaxy(:,3);
            elseif xys_index==4
                strMin=MinstrMin;
                strMax=MinstrMax;
                CcMatrix=sigmaxy(:,4);
            else
                strMin=MaxstrMin;
                strMax=MaxstrMax;
                CcMatrix=sigmaxy(:,5);
            end
            caxis( [strMin, strMax] ) ;
            colormap( 'jet' ) ;
            for ie=1:Pnp/3
                x = [NewPoint(3*(ie-1)+1,1);NewPoint(3*(ie-1)+2,1);NewPoint(3*(ie-1)+3,1)];
                y = [NewPoint(3*(ie-1)+1,2);NewPoint(3*(ie-1)+2,2);NewPoint(3*(ie-1)+3,2)];
                c = [CcMatrix(ie);CcMatrix(ie);CcMatrix(ie)] ;
                %if CcMatrix(ie)>-1e7
                 %   set( patch( x, y, c ), 'facecolor', 'b' ,'EdgeColor', 'none' ) ;
                %else
                    %set( patch( x, y, c ), 'facecolor', 'r' ,'EdgeColor', 'none' ) ;
                 %   set( patch( x, y, c ), 'EdgeColor', 'interp' ) ;
                %end
                set( patch( x, y, c ), 'EdgeColor', 'interp' ) ;
            end
            yTick = strMin:(strMax-strMin)/10:strMax ;
            Label = cell( 1, length(yTick) );
            for i=1:length(yTick)
                Label{i} = sprintf( '%.3fMPa', yTick(i)*1e-6) ;
            end
            set( colorbar('vert'), 'YTick', yTick, ...
            'YTickLabelMode','Manual','YTickLabel',Label) ;
end